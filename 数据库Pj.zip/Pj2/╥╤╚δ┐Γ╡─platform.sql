use `PCS`;
insert into `platform` (`platform_name`) values 
('京东'),
('拼多多'),
('闲鱼'),
('转转'),
('亚马逊');