use `PCS`;
insert into `seller` (`seller_name`, `password`, `fullname`, `address`, `description`, `phone_number`) values 
('sellerA', 'passA', 'ABC Electronics', '123 Tech St', 'Quality electronics retailer', '123-456-7890'),
('sellerB', 'passB', 'XYZ Appliances', '456 Gadget Ave', 'Your source for home appliances', '234-567-8901'),
('sellerC', 'passC', 'Tech Haven', '789 Innovation Blvd', 'Innovative tech solutions', '345-678-9012'),
('sellerD', 'passD', 'Fashion Trends', '101 Style Lane', 'Trendy fashion for all', '456-789-0123'),
('sellerE', 'passE', 'Sports Emporium', '202 Fitness Plaza', 'Your destination for sports gear', '567-890-1234')
