use `PCS`;
insert into `seller` (`seller_name`, `password`, `fullname`, `address`, `description`, `phone_number`) values 
('sellerF', 'passF', 'Books Galore', '303 Reading Road', 'A world of books at your fingertips', '678-901-2345'),
('sellerG', 'passG', 'Home Decor Haven', '404 Decor Drive', 'Elevate your living space', '789-012-3456'),
('sellerH', 'passH', 'Gourmet Delights', '505 Foodie Street', 'Delicious gourmet treats for every palate', '890-123-4567'),
('sellerI', 'passI', 'Pet Paradise', '606 Pet Lane', 'Everything your pet needs', '901-234-5678'),
('sellerJ', 'passJ', 'Green Thumb Nursery', '707 Garden Grove', 'Your garden, our passion', '012-345-6789');
