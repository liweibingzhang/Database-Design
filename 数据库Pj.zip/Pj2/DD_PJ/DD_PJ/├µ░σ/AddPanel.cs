﻿using DD_PJ;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pj_DBD
{
    public partial class AddPanel : Form
    {
        E_RelationType type;
        public AddPanel(E_RelationType type)
        {
            InitializeComponent();
            this.type = type;
            if (type == E_RelationType.Platform)
            {
                label_category.Hide();
                combo_category.Hide();
                Text = "添加平台";
            }
            else if (type == E_RelationType.Commodity)
            {
                combo_category.Items.Add("食品类");
                combo_category.Items.Add("服装类");
                combo_category.Items.Add("鞋帽类");
                combo_category.Items.Add("日用品类");
                combo_category.Items.Add("家具类");
                combo_category.Items.Add("家用电器类");
                combo_category.Items.Add("五金类");
                combo_category.Items.Add("厨具类");
                Text = "添加商品";
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (type == E_RelationType.Platform)
            {
                string name = text_commodity.Text;
                if (Manager.Instance.AddPlatform(name))
                {
                    MessageBox.Show("Add successful!");
                }
            }
            else if (type == E_RelationType.Commodity)
            {
                string name = text_commodity.Text;
                string category = combo_category.Text;
                if (Manager.Instance.AddCommodity(name, category))
                {
                    MessageBox.Show("Add successful!");
                }
            }
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            string name = text_commodity.Text;
            if (type == E_RelationType.Platform)
            {
                if (Manager.Instance.DeleteRecord(name, E_RelationType.Platform, ""))
                {
                    MessageBox.Show("Delete successful!");
                }
            }
            else if (type == E_RelationType.Commodity)
            {
                if (Manager.Instance.DeleteRecord(name, E_RelationType.Commodity, ""))
                {
                    MessageBox.Show("Delete successful!");
                }
            }
        }
    }
}
