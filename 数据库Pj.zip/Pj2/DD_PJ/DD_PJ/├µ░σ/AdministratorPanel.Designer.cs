﻿namespace pj_DBD
{
    partial class AdministratorPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_return = new System.Windows.Forms.Button();
            this.btn_user = new System.Windows.Forms.Button();
            this.btn_seller = new System.Windows.Forms.Button();
            this.btn_platform = new System.Windows.Forms.Button();
            this.btn_selling = new System.Windows.Forms.Button();
            this.btn_commodity = new System.Windows.Forms.Button();
            this.btn_addCommodity = new System.Windows.Forms.Button();
            this.btn_addPlatform = new System.Windows.Forms.Button();
            this.btn_addSeller = new System.Windows.Forms.Button();
            this.btn_addUser = new System.Windows.Forms.Button();
            this.btn_publish = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_favoriteDistribution = new System.Windows.Forms.Button();
            this.btn_priceRange = new System.Windows.Forms.Button();
            this.btn_priceDiff = new System.Windows.Forms.Button();
            this.btn_favoriteCount = new System.Windows.Forms.Button();
            this.btn_userFavorites = new System.Windows.Forms.Button();
            this.btn_userPriceInclination = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 11F);
            this.btn_return.Location = new System.Drawing.Point(356, 684);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(87, 36);
            this.btn_return.TabIndex = 70;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // btn_user
            // 
            this.btn_user.Font = new System.Drawing.Font("等线", 11F);
            this.btn_user.Location = new System.Drawing.Point(97, 62);
            this.btn_user.Name = "btn_user";
            this.btn_user.Size = new System.Drawing.Size(280, 36);
            this.btn_user.TabIndex = 71;
            this.btn_user.Text = "所有用户";
            this.btn_user.UseVisualStyleBackColor = true;
            this.btn_user.Click += new System.EventHandler(this.btn_user_Click);
            // 
            // btn_seller
            // 
            this.btn_seller.Font = new System.Drawing.Font("等线", 11F);
            this.btn_seller.Location = new System.Drawing.Point(97, 142);
            this.btn_seller.Name = "btn_seller";
            this.btn_seller.Size = new System.Drawing.Size(280, 36);
            this.btn_seller.TabIndex = 72;
            this.btn_seller.Text = "所有商家";
            this.btn_seller.UseVisualStyleBackColor = true;
            this.btn_seller.Click += new System.EventHandler(this.btn_seller_Click);
            // 
            // btn_platform
            // 
            this.btn_platform.Font = new System.Drawing.Font("等线", 11F);
            this.btn_platform.Location = new System.Drawing.Point(97, 222);
            this.btn_platform.Name = "btn_platform";
            this.btn_platform.Size = new System.Drawing.Size(280, 36);
            this.btn_platform.TabIndex = 73;
            this.btn_platform.Text = "所有平台";
            this.btn_platform.UseVisualStyleBackColor = true;
            this.btn_platform.Click += new System.EventHandler(this.btn_platform_Click);
            // 
            // btn_selling
            // 
            this.btn_selling.Font = new System.Drawing.Font("等线", 11F);
            this.btn_selling.Location = new System.Drawing.Point(97, 381);
            this.btn_selling.Name = "btn_selling";
            this.btn_selling.Size = new System.Drawing.Size(280, 36);
            this.btn_selling.TabIndex = 74;
            this.btn_selling.Text = "所有在售商品";
            this.btn_selling.UseVisualStyleBackColor = true;
            this.btn_selling.Click += new System.EventHandler(this.btn_selling_Click);
            // 
            // btn_commodity
            // 
            this.btn_commodity.Font = new System.Drawing.Font("等线", 11F);
            this.btn_commodity.Location = new System.Drawing.Point(97, 302);
            this.btn_commodity.Name = "btn_commodity";
            this.btn_commodity.Size = new System.Drawing.Size(280, 36);
            this.btn_commodity.TabIndex = 75;
            this.btn_commodity.Text = "所有商品";
            this.btn_commodity.UseVisualStyleBackColor = true;
            this.btn_commodity.Click += new System.EventHandler(this.btn_commodity_Click);
            // 
            // btn_addCommodity
            // 
            this.btn_addCommodity.Font = new System.Drawing.Font("等线", 11F);
            this.btn_addCommodity.Location = new System.Drawing.Point(462, 302);
            this.btn_addCommodity.Name = "btn_addCommodity";
            this.btn_addCommodity.Size = new System.Drawing.Size(210, 36);
            this.btn_addCommodity.TabIndex = 79;
            this.btn_addCommodity.Text = "增删商品";
            this.btn_addCommodity.UseVisualStyleBackColor = true;
            this.btn_addCommodity.Click += new System.EventHandler(this.btn_addCommodity_Click);
            // 
            // btn_addPlatform
            // 
            this.btn_addPlatform.Font = new System.Drawing.Font("等线", 11F);
            this.btn_addPlatform.Location = new System.Drawing.Point(462, 222);
            this.btn_addPlatform.Name = "btn_addPlatform";
            this.btn_addPlatform.Size = new System.Drawing.Size(210, 36);
            this.btn_addPlatform.TabIndex = 78;
            this.btn_addPlatform.Text = "增删平台";
            this.btn_addPlatform.UseVisualStyleBackColor = true;
            this.btn_addPlatform.Click += new System.EventHandler(this.btn_addPlatform_Click);
            // 
            // btn_addSeller
            // 
            this.btn_addSeller.Font = new System.Drawing.Font("等线", 11F);
            this.btn_addSeller.Location = new System.Drawing.Point(462, 142);
            this.btn_addSeller.Name = "btn_addSeller";
            this.btn_addSeller.Size = new System.Drawing.Size(210, 36);
            this.btn_addSeller.TabIndex = 77;
            this.btn_addSeller.Text = "添加商家";
            this.btn_addSeller.UseVisualStyleBackColor = true;
            this.btn_addSeller.Click += new System.EventHandler(this.btn_addSeller_Click);
            // 
            // btn_addUser
            // 
            this.btn_addUser.Font = new System.Drawing.Font("等线", 11F);
            this.btn_addUser.Location = new System.Drawing.Point(462, 62);
            this.btn_addUser.Name = "btn_addUser";
            this.btn_addUser.Size = new System.Drawing.Size(210, 36);
            this.btn_addUser.TabIndex = 76;
            this.btn_addUser.Text = "添加用户";
            this.btn_addUser.UseVisualStyleBackColor = true;
            this.btn_addUser.Click += new System.EventHandler(this.btn_addUser_Click);
            // 
            // btn_publish
            // 
            this.btn_publish.Font = new System.Drawing.Font("等线", 11F);
            this.btn_publish.Location = new System.Drawing.Point(462, 381);
            this.btn_publish.Name = "btn_publish";
            this.btn_publish.Size = new System.Drawing.Size(210, 36);
            this.btn_publish.TabIndex = 80;
            this.btn_publish.Text = "发布/更新";
            this.btn_publish.UseVisualStyleBackColor = true;
            this.btn_publish.Click += new System.EventHandler(this.btn_publish_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("等线", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(39, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 21);
            this.label1.TabIndex = 81;
            this.label1.Text = "基础查询";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("等线", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(39, 452);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 21);
            this.label2.TabIndex = 82;
            this.label2.Text = "进阶查询";
            // 
            // btn_favoriteDistribution
            // 
            this.btn_favoriteDistribution.Font = new System.Drawing.Font("等线", 11F);
            this.btn_favoriteDistribution.Location = new System.Drawing.Point(97, 549);
            this.btn_favoriteDistribution.Name = "btn_favoriteDistribution";
            this.btn_favoriteDistribution.Size = new System.Drawing.Size(280, 36);
            this.btn_favoriteDistribution.TabIndex = 83;
            this.btn_favoriteDistribution.Text = "收藏商品的分布情况";
            this.btn_favoriteDistribution.UseVisualStyleBackColor = true;
            this.btn_favoriteDistribution.Click += new System.EventHandler(this.btn_favoriteDistribution_Click);
            // 
            // btn_priceRange
            // 
            this.btn_priceRange.Font = new System.Drawing.Font("等线", 11F);
            this.btn_priceRange.Location = new System.Drawing.Point(425, 549);
            this.btn_priceRange.Name = "btn_priceRange";
            this.btn_priceRange.Size = new System.Drawing.Size(280, 36);
            this.btn_priceRange.TabIndex = 84;
            this.btn_priceRange.Text = "商品历史价格极差";
            this.btn_priceRange.UseVisualStyleBackColor = true;
            this.btn_priceRange.Click += new System.EventHandler(this.btn_priceRange_Click);
            // 
            // btn_priceDiff
            // 
            this.btn_priceDiff.Font = new System.Drawing.Font("等线", 11F);
            this.btn_priceDiff.Location = new System.Drawing.Point(425, 489);
            this.btn_priceDiff.Name = "btn_priceDiff";
            this.btn_priceDiff.Size = new System.Drawing.Size(280, 36);
            this.btn_priceDiff.TabIndex = 85;
            this.btn_priceDiff.Text = "商品在商家间的价格差异";
            this.btn_priceDiff.UseVisualStyleBackColor = true;
            this.btn_priceDiff.Click += new System.EventHandler(this.btn_priceDiff_Click);
            // 
            // btn_favoriteCount
            // 
            this.btn_favoriteCount.Font = new System.Drawing.Font("等线", 11F);
            this.btn_favoriteCount.Location = new System.Drawing.Point(97, 489);
            this.btn_favoriteCount.Name = "btn_favoriteCount";
            this.btn_favoriteCount.Size = new System.Drawing.Size(280, 36);
            this.btn_favoriteCount.TabIndex = 86;
            this.btn_favoriteCount.Text = "不同商品的收藏量";
            this.btn_favoriteCount.UseVisualStyleBackColor = true;
            this.btn_favoriteCount.Click += new System.EventHandler(this.btn_favoriteCount_Click);
            // 
            // btn_userFavorites
            // 
            this.btn_userFavorites.Font = new System.Drawing.Font("等线", 11F);
            this.btn_userFavorites.Location = new System.Drawing.Point(97, 609);
            this.btn_userFavorites.Name = "btn_userFavorites";
            this.btn_userFavorites.Size = new System.Drawing.Size(280, 36);
            this.btn_userFavorites.TabIndex = 87;
            this.btn_userFavorites.Text = "用户的收藏夹";
            this.btn_userFavorites.UseVisualStyleBackColor = true;
            this.btn_userFavorites.Click += new System.EventHandler(this.btn_userFavorites_Click);
            // 
            // btn_userPriceInclination
            // 
            this.btn_userPriceInclination.Font = new System.Drawing.Font("等线", 11F);
            this.btn_userPriceInclination.Location = new System.Drawing.Point(425, 609);
            this.btn_userPriceInclination.Name = "btn_userPriceInclination";
            this.btn_userPriceInclination.Size = new System.Drawing.Size(280, 36);
            this.btn_userPriceInclination.TabIndex = 88;
            this.btn_userPriceInclination.Text = "用户收藏的价格倾向";
            this.btn_userPriceInclination.UseVisualStyleBackColor = true;
            this.btn_userPriceInclination.Click += new System.EventHandler(this.btn_userPriceInclination_Click);
            // 
            // AdministratorPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 734);
            this.Controls.Add(this.btn_userPriceInclination);
            this.Controls.Add(this.btn_userFavorites);
            this.Controls.Add(this.btn_favoriteCount);
            this.Controls.Add(this.btn_priceDiff);
            this.Controls.Add(this.btn_priceRange);
            this.Controls.Add(this.btn_favoriteDistribution);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_publish);
            this.Controls.Add(this.btn_addCommodity);
            this.Controls.Add(this.btn_addPlatform);
            this.Controls.Add(this.btn_addSeller);
            this.Controls.Add(this.btn_addUser);
            this.Controls.Add(this.btn_commodity);
            this.Controls.Add(this.btn_selling);
            this.Controls.Add(this.btn_platform);
            this.Controls.Add(this.btn_seller);
            this.Controls.Add(this.btn_user);
            this.Controls.Add(this.btn_return);
            this.Name = "AdministratorPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdministratorPanel";
            this.Activated += new System.EventHandler(this.AdministratorPanel_Activated);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AdministratorPanel_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Button btn_user;
        private System.Windows.Forms.Button btn_seller;
        private System.Windows.Forms.Button btn_platform;
        private System.Windows.Forms.Button btn_selling;
        private System.Windows.Forms.Button btn_commodity;
        private System.Windows.Forms.Button btn_addCommodity;
        private System.Windows.Forms.Button btn_addPlatform;
        private System.Windows.Forms.Button btn_addSeller;
        private System.Windows.Forms.Button btn_addUser;
        private System.Windows.Forms.Button btn_publish;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_favoriteDistribution;
        private System.Windows.Forms.Button btn_priceRange;
        private System.Windows.Forms.Button btn_priceDiff;
        private System.Windows.Forms.Button btn_favoriteCount;
        private System.Windows.Forms.Button btn_userFavorites;
        private System.Windows.Forms.Button btn_userPriceInclination;
    }
}