﻿namespace DD_PJ
{
    partial class SellerPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_fullname = new System.Windows.Forms.Label();
            this.text_fullname = new System.Windows.Forms.TextBox();
            this.text_address = new System.Windows.Forms.TextBox();
            this.label_address = new System.Windows.Forms.Label();
            this.text_description = new System.Windows.Forms.TextBox();
            this.label_description = new System.Windows.Forms.Label();
            this.btn_return = new System.Windows.Forms.Button();
            this.btn_publish = new System.Windows.Forms.Button();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.text_password = new System.Windows.Forms.TextBox();
            this.label_password = new System.Windows.Forms.Label();
            this.btn_selling = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.label_phone = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_fullname
            // 
            this.label_fullname.AutoSize = true;
            this.label_fullname.Font = new System.Drawing.Font("等线", 11F);
            this.label_fullname.Location = new System.Drawing.Point(45, 43);
            this.label_fullname.Name = "label_fullname";
            this.label_fullname.Size = new System.Drawing.Size(81, 19);
            this.label_fullname.TabIndex = 4;
            this.label_fullname.Text = "全　   称";
            // 
            // text_fullname
            // 
            this.text_fullname.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_fullname.Location = new System.Drawing.Point(135, 40);
            this.text_fullname.MaxLength = 40;
            this.text_fullname.Name = "text_fullname";
            this.text_fullname.ReadOnly = true;
            this.text_fullname.Size = new System.Drawing.Size(601, 26);
            this.text_fullname.TabIndex = 7;
            // 
            // text_address
            // 
            this.text_address.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_address.Location = new System.Drawing.Point(135, 133);
            this.text_address.MaxLength = 50;
            this.text_address.Name = "text_address";
            this.text_address.ReadOnly = true;
            this.text_address.Size = new System.Drawing.Size(601, 26);
            this.text_address.TabIndex = 11;
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("等线", 11F);
            this.label_address.Location = new System.Drawing.Point(45, 136);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(81, 19);
            this.label_address.TabIndex = 10;
            this.label_address.Text = "地　   址";
            // 
            // text_description
            // 
            this.text_description.Font = new System.Drawing.Font("等线", 10.8F);
            this.text_description.Location = new System.Drawing.Point(135, 190);
            this.text_description.MaxLength = 100;
            this.text_description.Multiline = true;
            this.text_description.Name = "text_description";
            this.text_description.ReadOnly = true;
            this.text_description.Size = new System.Drawing.Size(601, 78);
            this.text_description.TabIndex = 13;
            // 
            // label_description
            // 
            this.label_description.AutoSize = true;
            this.label_description.Font = new System.Drawing.Font("等线", 11F);
            this.label_description.Location = new System.Drawing.Point(45, 193);
            this.label_description.Name = "label_description";
            this.label_description.Size = new System.Drawing.Size(85, 19);
            this.label_description.TabIndex = 12;
            this.label_description.Text = "详细描述";
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 11F);
            this.btn_return.Location = new System.Drawing.Point(357, 413);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(87, 36);
            this.btn_return.TabIndex = 16;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // btn_publish
            // 
            this.btn_publish.Font = new System.Drawing.Font("等线", 11F);
            this.btn_publish.Location = new System.Drawing.Point(254, 349);
            this.btn_publish.Name = "btn_publish";
            this.btn_publish.Size = new System.Drawing.Size(112, 33);
            this.btn_publish.TabIndex = 18;
            this.btn_publish.Text = "发布商品";
            this.btn_publish.UseVisualStyleBackColor = true;
            this.btn_publish.Click += new System.EventHandler(this.btn_publish_Click);
            // 
            // btn_edit
            // 
            this.btn_edit.Font = new System.Drawing.Font("等线", 11F);
            this.btn_edit.Location = new System.Drawing.Point(357, 294);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(87, 36);
            this.btn_edit.TabIndex = 20;
            this.btn_edit.Text = "编辑";
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("等线", 11F);
            this.btn_save.Location = new System.Drawing.Point(279, 294);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(87, 36);
            this.btn_save.TabIndex = 21;
            this.btn_save.Text = "保存";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("等线", 11F);
            this.btn_cancel.Location = new System.Drawing.Point(433, 294);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(87, 36);
            this.btn_cancel.TabIndex = 25;
            this.btn_cancel.Text = "取消";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // text_password
            // 
            this.text_password.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_password.Location = new System.Drawing.Point(500, 89);
            this.text_password.MaxLength = 40;
            this.text_password.Name = "text_password";
            this.text_password.ReadOnly = true;
            this.text_password.Size = new System.Drawing.Size(236, 26);
            this.text_password.TabIndex = 27;
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("等线", 11F);
            this.label_password.Location = new System.Drawing.Point(428, 92);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(66, 19);
            this.label_password.TabIndex = 26;
            this.label_password.Text = "密　码";
            // 
            // btn_selling
            // 
            this.btn_selling.Font = new System.Drawing.Font("等线", 11F);
            this.btn_selling.Location = new System.Drawing.Point(433, 349);
            this.btn_selling.Name = "btn_selling";
            this.btn_selling.Size = new System.Drawing.Size(112, 33);
            this.btn_selling.TabIndex = 28;
            this.btn_selling.Text = "在售商品";
            this.btn_selling.UseVisualStyleBackColor = true;
            this.btn_selling.Click += new System.EventHandler(this.btn_selling_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("等线", 11F);
            this.btn_delete.Location = new System.Drawing.Point(339, 347);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(125, 36);
            this.btn_delete.TabIndex = 59;
            this.btn_delete.Text = "删除该商家";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // text_phone
            // 
            this.text_phone.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_phone.Location = new System.Drawing.Point(135, 89);
            this.text_phone.MaxLength = 20;
            this.text_phone.Name = "text_phone";
            this.text_phone.ReadOnly = true;
            this.text_phone.Size = new System.Drawing.Size(230, 26);
            this.text_phone.TabIndex = 61;
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("等线", 11F);
            this.label_phone.Location = new System.Drawing.Point(44, 92);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(85, 19);
            this.label_phone.TabIndex = 60;
            this.label_phone.Text = "联系电话";
            // 
            // SellerPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 463);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_selling);
            this.Controls.Add(this.text_password);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.btn_publish);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.text_description);
            this.Controls.Add(this.label_description);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.text_fullname);
            this.Controls.Add(this.label_fullname);
            this.Name = "SellerPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SellerPanel";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SellerPanel_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_fullname;
        private System.Windows.Forms.TextBox text_fullname;
        private System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.Label label_address;
        private System.Windows.Forms.TextBox text_description;
        private System.Windows.Forms.Label label_description;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Button btn_publish;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.TextBox text_password;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Button btn_selling;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Label label_phone;
    }
}