﻿namespace DD_PJ
{
    partial class ChartPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.mainChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btn_return = new System.Windows.Forms.Button();
            this.combo2 = new System.Windows.Forms.ComboBox();
            this.label_priceLabel = new System.Windows.Forms.Label();
            this.label_lowestPrice = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.combo1 = new System.Windows.Forms.ComboBox();
            this.btn_changeForm = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.mainChart)).BeginInit();
            this.SuspendLayout();
            // 
            // mainChart
            // 
            chartArea2.Name = "ChartArea1";
            this.mainChart.ChartAreas.Add(chartArea2);
            this.mainChart.Location = new System.Drawing.Point(45, 84);
            this.mainChart.Name = "mainChart";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Color = System.Drawing.Color.IndianRed;
            series2.IsValueShownAsLabel = true;
            series2.Name = "Series1";
            this.mainChart.Series.Add(series2);
            this.mainChart.Size = new System.Drawing.Size(708, 340);
            this.mainChart.TabIndex = 0;
            this.mainChart.Text = "chart1";
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 11F);
            this.btn_return.Location = new System.Drawing.Point(357, 501);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(87, 36);
            this.btn_return.TabIndex = 33;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // combo2
            // 
            this.combo2.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.combo2.FormattingEnabled = true;
            this.combo2.Location = new System.Drawing.Point(516, 34);
            this.combo2.Name = "combo2";
            this.combo2.Size = new System.Drawing.Size(175, 27);
            this.combo2.TabIndex = 34;
            this.combo2.SelectedIndexChanged += new System.EventHandler(this.SelectedIndexChanged);
            this.combo2.TextUpdate += new System.EventHandler(this.combo2_TextUpdate);
            // 
            // label_priceLabel
            // 
            this.label_priceLabel.AutoSize = true;
            this.label_priceLabel.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_priceLabel.Location = new System.Drawing.Point(319, 458);
            this.label_priceLabel.Name = "label_priceLabel";
            this.label_priceLabel.Size = new System.Drawing.Size(99, 19);
            this.label_priceLabel.TabIndex = 35;
            this.label_priceLabel.Text = "最低价格：";
            // 
            // label_lowestPrice
            // 
            this.label_lowestPrice.AutoSize = true;
            this.label_lowestPrice.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_lowestPrice.Location = new System.Drawing.Point(424, 458);
            this.label_lowestPrice.Name = "label_lowestPrice";
            this.label_lowestPrice.Size = new System.Drawing.Size(40, 19);
            this.label_lowestPrice.TabIndex = 36;
            this.label_lowestPrice.Text = "0.00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("等线", 11F);
            this.label2.Location = new System.Drawing.Point(424, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 37;
            this.label2.Text = "时间跨度 ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("等线", 11F);
            this.label1.Location = new System.Drawing.Point(94, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 19);
            this.label1.TabIndex = 39;
            this.label1.Text = "商品名";
            // 
            // combo1
            // 
            this.combo1.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.combo1.FormattingEnabled = true;
            this.combo1.Location = new System.Drawing.Point(186, 34);
            this.combo1.Name = "combo1";
            this.combo1.Size = new System.Drawing.Size(175, 27);
            this.combo1.TabIndex = 38;
            this.combo1.SelectedIndexChanged += new System.EventHandler(this.SelectedIndexChanged);
            this.combo1.TextUpdate += new System.EventHandler(this.combo1_TextUpdate);
            // 
            // btn_changeForm
            // 
            this.btn_changeForm.Font = new System.Drawing.Font("等线", 11F);
            this.btn_changeForm.Location = new System.Drawing.Point(347, 449);
            this.btn_changeForm.Name = "btn_changeForm";
            this.btn_changeForm.Size = new System.Drawing.Size(107, 36);
            this.btn_changeForm.TabIndex = 40;
            this.btn_changeForm.Text = "切换显示";
            this.btn_changeForm.UseVisualStyleBackColor = true;
            this.btn_changeForm.Click += new System.EventHandler(this.btn_changeForm_Click);
            // 
            // ChartPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 549);
            this.Controls.Add(this.btn_changeForm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combo1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_lowestPrice);
            this.Controls.Add(this.label_priceLabel);
            this.Controls.Add(this.combo2);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.mainChart);
            this.Name = "ChartPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChartPanel";
            ((System.ComponentModel.ISupportInitialize)(this.mainChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart mainChart;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.ComboBox combo2;
        private System.Windows.Forms.Label label_priceLabel;
        private System.Windows.Forms.Label label_lowestPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox combo1;
        private System.Windows.Forms.Button btn_changeForm;
    }
}