﻿namespace DD_PJ
{
    partial class RegisertPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_return = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.text_password = new System.Windows.Forms.TextBox();
            this.text_name = new System.Windows.Forms.TextBox();
            this.label_password = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_title = new System.Windows.Forms.Label();
            this.btn_showPwd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 12F);
            this.btn_return.Location = new System.Drawing.Point(447, 357);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(97, 42);
            this.btn_return.TabIndex = 15;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // btn_register
            // 
            this.btn_register.Font = new System.Drawing.Font("等线", 12F);
            this.btn_register.Location = new System.Drawing.Point(258, 357);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(97, 42);
            this.btn_register.TabIndex = 14;
            this.btn_register.Text = "注 册";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // text_password
            // 
            this.text_password.Font = new System.Drawing.Font("等线", 11F);
            this.text_password.Location = new System.Drawing.Point(292, 249);
            this.text_password.MaxLength = 20;
            this.text_password.Name = "text_password";
            this.text_password.PasswordChar = '*';
            this.text_password.Size = new System.Drawing.Size(277, 27);
            this.text_password.TabIndex = 13;
            // 
            // text_name
            // 
            this.text_name.Font = new System.Drawing.Font("等线", 11F);
            this.text_name.Location = new System.Drawing.Point(292, 162);
            this.text_name.MaxLength = 20;
            this.text_name.Name = "text_name";
            this.text_name.Size = new System.Drawing.Size(277, 27);
            this.text_name.TabIndex = 12;
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.BackColor = System.Drawing.SystemColors.Control;
            this.label_password.Font = new System.Drawing.Font("等线", 13F);
            this.label_password.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_password.Location = new System.Drawing.Point(197, 249);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(76, 23);
            this.label_password.TabIndex = 11;
            this.label_password.Text = "密　码";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.BackColor = System.Drawing.SystemColors.Control;
            this.label_name.Font = new System.Drawing.Font("等线", 13F);
            this.label_name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_name.Location = new System.Drawing.Point(197, 162);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(76, 23);
            this.label_name.TabIndex = 10;
            this.label_name.Text = "用户名";
            // 
            // label_title
            // 
            this.label_title.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_title.BackColor = System.Drawing.SystemColors.Control;
            this.label_title.Font = new System.Drawing.Font("等线", 20F);
            this.label_title.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_title.Location = new System.Drawing.Point(252, 63);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(311, 36);
            this.label_title.TabIndex = 9;
            this.label_title.Text = "用户注册";
            this.label_title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_showPwd
            // 
            this.btn_showPwd.Font = new System.Drawing.Font("等线", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_showPwd.Location = new System.Drawing.Point(568, 249);
            this.btn_showPwd.Name = "btn_showPwd";
            this.btn_showPwd.Size = new System.Drawing.Size(54, 30);
            this.btn_showPwd.TabIndex = 16;
            this.btn_showPwd.Text = "显示";
            this.btn_showPwd.UseVisualStyleBackColor = true;
            this.btn_showPwd.Click += new System.EventHandler(this.btn_showPwd_Click);
            // 
            // RegisertPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_showPwd);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.btn_register);
            this.Controls.Add(this.text_password);
            this.Controls.Add(this.text_name);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.label_title);
            this.Name = "RegisertPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegisertPanel";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.RegisertPanel_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.TextBox text_password;
        private System.Windows.Forms.TextBox text_name;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.Button btn_showPwd;
    }
}