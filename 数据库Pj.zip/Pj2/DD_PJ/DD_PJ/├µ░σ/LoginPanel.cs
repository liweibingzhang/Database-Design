﻿using DD_PJ;
using pj_DBD;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DD_PJ
{
    /// <summary>
    /// 登入面板
    /// </summary>
    public partial class LoginPanel : Form
    {
        /// <summary>
        /// 用户类型
        /// </summary>
        E_RelationType userType;

        /// <summary>
        /// 初始面板
        /// </summary>
        InitialPanel initialPanel;

        /// <summary>
        /// 密码是否显示
        /// </summary>
        bool isShown = false;

        /// <summary>
        /// 密码掩码
        /// </summary>
        char C => isShown ? '\0' : '*';

        /// <summary>
        /// 面板关闭后是否切换到初始面板
        /// </summary>
        bool switchToInitialPanel = true;

        /// <summary>
        /// 注册表
        /// </summary>
        Dictionary<string, string> registry;

        public LoginPanel(E_RelationType userType, InitialPanel initialPanel)
        {
            InitializeComponent();
            this.initialPanel = initialPanel;
            this.userType = userType;

            switch (userType)
            {
                case E_RelationType.User:
                    label_title.Text = "用户登入";
                    label_name.Text = "用户名";
                    break;
                case E_RelationType.Seller:
                    label_title.Text = "商家登入";
                    label_name.Text = "商家名";
                    break;
                case E_RelationType.Administrator:
                    label_name.Hide();
                    combo_name.Hide();
                    linkLabel_register.Hide();
                    btn_showPwd.Hide();
                    label_title.Text = "管理员登入";
                    int x = label_password.Location.X;
                    int y = label_password.Location.Y;
                    label_password.Location = new Point(x, y - 40);
                    x = text_password.Location.X;
                    y = text_password.Location.Y;
                    text_password.Location = new Point(x, y - 40);
                    combo_name.Text = "administrator";
                    break;
                default:
                    break;
            }

            Text = label_title.Text;
        }

        /// <summary>
        /// 每次面板显示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginPanel_Activated(object sender, EventArgs e)
        {
            //每次显示窗口
            //从管理员处获取用户名和密码 用于登录时判断
            registry = Manager.Instance.GetRegistry(userType);
            combo_name.Items.Clear();
            foreach (string name in registry.Keys)
            {
                combo_name.Items.Add(name);
            }
        }

        /// <summary>
        /// 登录的方法
        /// </summary>
        void Login()
        {
            string name = combo_name.Text;
            string password = text_password.Text;

            //登录失败
            object info;
            if ((info = CheckLogin(name, password, userType)) == null)
            {
                return;
            }

            //登录成功
            switchToInitialPanel = false;
            switch (userType)
            {
                case E_RelationType.User:
                    new UserPanel(initialPanel, info as UserInfo).Show();
                    break;
                case E_RelationType.Seller:
                    new SellerPanel(initialPanel, info as SellerInfo).Show();
                    break;
                case E_RelationType.Administrator:
                    //管理员登录逻辑
                    new AdministratorPanel(initialPanel).Show();
                    break;
                default:
                    break;
            }
            Close();
        }

        /// <summary>
        /// 检查登录是否成功
        /// </summary>
        /// <param name="name">用户/商家名</param>
        /// <param name="password">密码</param>
        /// <param name="userType">用户类型</param>
        /// <returns>登录成功则返回登录的用户/商家的信息，不成功则返回null</returns>
        object CheckLogin(string name, string password, E_RelationType userType)
        {
            if (!registry.ContainsKey(name))
            {
                MessageBox.Show("用户名错误！");
                return null;
            }
            if (registry[name] != password)
            {
                MessageBox.Show("密码错误！");
                return null;
            }
            return Manager.Instance.GetRecord(name, userType, "name");

            //检查用户名
            /*switch (userType)
            {
                case E_UserType.User:
                    UserInfo matchedUser = null;
                    foreach (UserInfo user in users.Values)
                    {
                        if (user.user_name == name)
                        {
                            matchedUser = user;
                            break;
                        }
                    }
                    //没有匹配的用户名
                    if (matchedUser == null)
                    {
                        MessageBox.Show("用户名错误");
                        return null;
                    }
                    //检查密码
                    //密码错误
                    if (password != matchedUser.password)
                    {
                        MessageBox.Show("密码错误");
                        return null;
                    }
                    //密码正确
                    return matchedUser;
                case E_UserType.Seller:
                    SellerInfo matchedSeller = null;
                    foreach (SellerInfo seller in sellers.Values)
                    {
                        if (seller.seller_name == name)
                        {
                            matchedSeller = seller;
                            break;
                        }
                    }
                    //没有匹配的商家名
                    if (matchedSeller == null)
                    {
                        MessageBox.Show("商家名错误");
                        return null;
                    }
                    //检查密码
                    //密码错误
                    if (password != matchedSeller.password)
                    {
                        MessageBox.Show("密码错误");
                        return null;
                    }
                    //密码正确
                    return matchedSeller;
                case E_UserType.Administrator:
                    //密码错误
                    if (password != "123456")
                    {
                        MessageBox.Show("密码错误");
                        return null;
                    }
                    //密码正确
                    return "";
                default:
                    break;
            }
            return null;*/
        }

        /// <summary>
        /// 点击登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_login_Click(object sender, EventArgs e)
        {
            //登录
            Login();
        }

        /// <summary>
        /// 点击返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 每次面板关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginPanel_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (switchToInitialPanel)
                initialPanel.Show();
        }

        /// <summary>
        /// 点击链接文本
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void linkLabel_register_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new RegisertPanel(userType, this).Show();
            Hide();
        }

        /// <summary>
        /// 点击显示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_showPwd_Click(object sender, EventArgs e)
        {
            isShown = !isShown;
            text_password.PasswordChar = C;
        }

        /// <summary>
        /// 按下回车
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginPanel_KeyUp(object sender, KeyEventArgs e)
        {
            //按下回车并且用户名和密码都不为空
            if (e.KeyCode == Keys.Enter && !(combo_name.Text == "" || text_password.Text == ""))
            {
                //检测登录
                Login();
            }
        }
    }
}
