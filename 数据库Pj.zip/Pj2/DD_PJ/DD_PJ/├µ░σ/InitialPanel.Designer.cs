﻿namespace DD_PJ
{
    partial class InitialPanel
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_asUser = new System.Windows.Forms.Button();
            this.btn_asSeller = new System.Windows.Forms.Button();
            this.btn_asManager = new System.Windows.Forms.Button();
            this.btn_return = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("等线", 20F);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(355, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "登 入";
            // 
            // btn_asUser
            // 
            this.btn_asUser.Font = new System.Drawing.Font("等线", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_asUser.Location = new System.Drawing.Point(323, 125);
            this.btn_asUser.Name = "btn_asUser";
            this.btn_asUser.Size = new System.Drawing.Size(155, 40);
            this.btn_asUser.TabIndex = 1;
            this.btn_asUser.Text = "我是用户";
            this.btn_asUser.UseVisualStyleBackColor = true;
            this.btn_asUser.Click += new System.EventHandler(this.btn_asUser_Click);
            // 
            // btn_asSeller
            // 
            this.btn_asSeller.Font = new System.Drawing.Font("等线", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_asSeller.Location = new System.Drawing.Point(323, 208);
            this.btn_asSeller.Name = "btn_asSeller";
            this.btn_asSeller.Size = new System.Drawing.Size(155, 40);
            this.btn_asSeller.TabIndex = 2;
            this.btn_asSeller.Text = "我是商家";
            this.btn_asSeller.UseVisualStyleBackColor = true;
            this.btn_asSeller.Click += new System.EventHandler(this.btn_asSeller_Click);
            // 
            // btn_asManager
            // 
            this.btn_asManager.Font = new System.Drawing.Font("等线", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_asManager.Location = new System.Drawing.Point(323, 294);
            this.btn_asManager.Name = "btn_asManager";
            this.btn_asManager.Size = new System.Drawing.Size(155, 40);
            this.btn_asManager.TabIndex = 3;
            this.btn_asManager.Text = "我是管理员";
            this.btn_asManager.UseVisualStyleBackColor = true;
            this.btn_asManager.Click += new System.EventHandler(this.btn_asManager_Click);
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 12F);
            this.btn_return.Location = new System.Drawing.Point(350, 389);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(97, 40);
            this.btn_return.TabIndex = 8;
            this.btn_return.Text = "退 出";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // InitialPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.btn_asManager);
            this.Controls.Add(this.btn_asSeller);
            this.Controls.Add(this.btn_asUser);
            this.Controls.Add(this.label1);
            this.Name = "InitialPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "比价系统";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.InitialPanel_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_asUser;
        private System.Windows.Forms.Button btn_asSeller;
        private System.Windows.Forms.Button btn_asManager;
        private System.Windows.Forms.Button btn_return;
    }
}

