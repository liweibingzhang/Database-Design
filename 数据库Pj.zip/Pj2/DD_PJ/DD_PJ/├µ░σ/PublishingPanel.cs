﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DD_PJ
{
    public partial class PublishingPanel : Form
    {
        /// <summary>
        /// 在售商品的信息
        /// </summary>
        List<SellingInfo> sellingInfoList;

        /// <summary>
        /// 当前选择下的在售商品信息
        /// </summary>
        SellingInfo selectedSellingInfo;

        public PublishingPanel(List<SellingInfo> sellingInfoList)
        {
            InitializeComponent();
            this.sellingInfoList = sellingInfoList;


            List<string> sellerNames     = Manager.Instance.GetNames(E_RelationType.Seller);
            List<string> commoditiesName = Manager.Instance.GetNames(E_RelationType.Commodity);
            List<string> platformsName   = Manager.Instance.GetNames(E_RelationType.Platform);

            Text = "发布/更新在售商品信息";

            combo_commodityName.Items.Clear();
            foreach (string name in commoditiesName)
            {
                combo_commodityName.Items.Add(name);
            }
            combo_platformName.Items.Clear();
            foreach (string name in platformsName)
            {
                combo_platformName.Items.Add(name);
            }
            combo_sellerName.Items.Clear();
            foreach (string name in sellerNames)
            {
                combo_sellerName.Items.Add(name);
            }
        }

        public PublishingPanel(string sellerName, List<SellingInfo> sellingInfoList) : this(sellingInfoList)
        {
            combo_sellerName.Text = sellerName;

            label2.Hide();
            combo_sellerName.Hide();
        }

        /// <summary>
        /// 显示所选在售商品的信息
        /// </summary>
        void ShowSellingInfo()
        {
            if (combo_commodityName.Text.Length != 0 && combo_platformName.Text.Length != 0 && combo_sellerName.Text.Length != 0)
            {
                selectedSellingInfo = null;
                foreach (SellingInfo info in sellingInfoList)
                {
                    if (info.commodity_name == combo_commodityName.Text &&
                        info.platform_name  == combo_platformName.Text &&
                        info.seller_name    == combo_sellerName.Text)
                    {
                        selectedSellingInfo = info;
                    }
                }
                Reset();
            }
            else
            {
                selectedSellingInfo = null;

                Reset();
            }
        }

        /// <summary>
        /// 重置商品信息
        /// </summary>
        void Reset()
        {
            if (selectedSellingInfo != null)
            {
                string[] price = selectedSellingInfo.price.Split('.');
                text_priceInt.Text = price[0];
                text_priceDec.Text = price[1];
                dateTime_produceDate.Text = selectedSellingInfo.produce_date;
                text_life.Text            = selectedSellingInfo.shelf_life;
                text_produceAddress.Text  = selectedSellingInfo.produce_address;
                text_description.Text     = selectedSellingInfo.description;
            }
            else
            {
                text_priceInt.Clear();
                text_priceDec.Clear();
                text_life.Clear();
                text_produceAddress.Clear();
                text_description.Clear();
            }
        }

        /// <summary>
        /// 发布商品
        /// </summary>
        void Publish()
        {
            string comodityName = combo_commodityName.Text;
            string platformName = combo_platformName.Text;
            string sellerName   = combo_sellerName.Text;
            if (comodityName.Length == 0 || platformName.Length == 0)
            {
                MessageBox.Show("请选择商品和平台");
                return;
            }
            if (sellerName.Length == 0)
            {
                MessageBox.Show("请选择商家");
                return;
            }
            if (!combo_commodityName.Items.Contains(comodityName) || !combo_platformName.Items.Contains(platformName))
            {
                MessageBox.Show("商品或平台不存在!");
                return;
            }
            if (!combo_sellerName.Items.Contains(sellerName))
            {
                MessageBox.Show("商家不存在!");
                return;
            }
            if (text_priceInt.Text.Length == 0)
            {
                MessageBox.Show("售价不能为空");
                return;
            }
            if (text_priceDec.Text.Length != 2)
            {
                MessageBox.Show("售价的小数部分不完整");
                return;
            }
            if (text_life.Text.Length == 0)
            {
                MessageBox.Show("保质期不能为空");
                return;
            }
            if (text_produceAddress.Text.Length == 0)
            {
                MessageBox.Show("生产地址不能为空");
                return;
            }
            string price = text_priceInt.Text + "." + text_priceDec.Text;
            //商品信息是否已经存在于数据库
            bool exists = true;
            if (selectedSellingInfo == null)
            {
                exists = false;
                selectedSellingInfo = new SellingInfo();

                selectedSellingInfo.commodity_name = combo_commodityName.SelectedItem.ToString();
                selectedSellingInfo.platform_name  = combo_platformName.SelectedItem.ToString();
                selectedSellingInfo.seller_name    = combo_sellerName.SelectedItem.ToString();

                CommodityInfo commodityInfo        = Manager.Instance.GetRecord(selectedSellingInfo.commodity_name, E_RelationType.Commodity, "name") as CommodityInfo;
                selectedSellingInfo.commodity_id   = commodityInfo.ID;
                SellerInfo sellerInfo              = Manager.Instance.GetRecord(selectedSellingInfo.seller_name, E_RelationType.Seller, "name") as SellerInfo;
                selectedSellingInfo.seller_id      = sellerInfo.ID;
                (string id, string name) platform  = ((string id, string name))Manager.Instance.GetRecord(selectedSellingInfo.platform_name, E_RelationType.Platform, "name");
                selectedSellingInfo.platform_id    = platform.id;

                sellingInfoList.Add(selectedSellingInfo);
            }
            selectedSellingInfo.price           = price;
            selectedSellingInfo.produce_date    = DateTime.Parse(dateTime_produceDate.Text).ToString("yy-MM-dd");
            selectedSellingInfo.shelf_life      = text_life.Text;
            selectedSellingInfo.produce_address = text_produceAddress.Text;
            selectedSellingInfo.description     = text_description.Text;

            if (exists)
                Manager.Instance.UpdateSellingInfo(selectedSellingInfo);
            else
                Manager.Instance.Publish(selectedSellingInfo);
        }

        /// <summary>
        /// 输入售价的整数部分
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void text_priceInt_KeyPress(object sender, KeyPressEventArgs e)
        {
            //如果输入的不是退格和数字，则屏蔽输入
            if (!(e.KeyChar == '\b' || (e.KeyChar >= '0' && e.KeyChar <= '9')))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 输入售价的小数部分
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void text_priceDec_KeyPress(object sender, KeyPressEventArgs e)
        {
            //如果输入的不是退格和数字，则屏蔽输入
            if (!(e.KeyChar == '\b' || (e.KeyChar >= '0' && e.KeyChar <= '9')))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 输入保质期
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void text_life_KeyPress(object sender, KeyPressEventArgs e)
        {
            //如果输入的不是退格和数字，则屏蔽输入
            if (!(e.KeyChar == '\b' || (e.KeyChar >= '0' && e.KeyChar <= '9')))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 点击发布
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_publish_Click(object sender, EventArgs e)
        {
            Publish();
        }

        /// <summary>
        /// 点击重置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_reset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        /// <summary>
        /// 点击返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void combo_commodityName_TextChanged(object sender, EventArgs e)
        {
            ShowSellingInfo();
        }

        private void combo_platformName_TextChanged(object sender, EventArgs e)
        {
            ShowSellingInfo();
        }

        private void combo_sellerName_TextChanged(object sender, EventArgs e)
        {
            ShowSellingInfo();
        }
    }
}
