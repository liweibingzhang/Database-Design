﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace DD_PJ
{
    /// <summary>
    /// 在售商品信息面板
    /// </summary>
    public partial class SellingPanel : Form
    {
        /// <summary>
        /// 要显示的在售商品的信息
        /// </summary>
        SellingInfo sellingInfo;

        /// <summary>
        /// 添加到用户收藏夹的事件
        /// </summary>
        event Action<SellingInfo> AddToFavorites;

        /// <summary>
        /// 将商品移出用户收藏夹的事件
        /// </summary>
        event Action<SellingInfo> RemoveFromFavorites;

        /// <summary>
        /// 将商品移出商家的在售商品列表
        /// </summary>
        event Action<SellingInfo> RemoveFromSellingList;

        public SellingPanel(SellingInfo sellingInfo, E_RelationType userType)
        {
            InitializeComponent();
            this.sellingInfo = sellingInfo;

            switch (userType)
            {
                case E_RelationType.User:
                    if (sellingInfo.isFavorite)
                    {
                        btn_cancel.Show();
                        btn_collect.Hide();
                        text_priceFloorInt.ReadOnly = true;
                        text_priceFloorDec.ReadOnly = true;
                    }
                    else
                    {
                        btn_cancel.Hide();
                        btn_collect.Show();
                        text_priceFloorInt.ReadOnly = false;
                        text_priceFloorDec.ReadOnly = false;
                    }
                    btn_showHistory.Show();
                    btn_remove.Hide();

                    label_priceFloor.Show();
                    text_priceFloorInt.Show();
                    text_priceFloorDec.Show();
                    label_point.Show();
                    label_yuan.Show();
                    if (sellingInfo.priceFloor != null && sellingInfo.priceFloor != "")
                    {
                        string[] priceFloor = sellingInfo.priceFloor.ToString().Split('.');
                        text_priceFloorInt.Text = priceFloor[0];
                        text_priceFloorDec.Text = priceFloor[1];
                    }
                    break;
                case E_RelationType.Seller:
                    btn_collect.Hide();
                    btn_showHistory.Hide();
                    btn_cancel.Hide();

                    label_priceFloor.Hide();
                    text_priceFloorInt.Hide();
                    text_priceFloorDec.Hide();
                    label_point.Hide();
                    label_yuan.Hide();
                    break;
                case E_RelationType.Administrator:
                    btn_collect.Hide();
                    btn_showHistory.Show();
                    btn_remove.Show();
                    btn_cancel.Hide();

                    label_priceFloor.Hide();
                    text_priceFloorInt.Hide();
                    text_priceFloorDec.Hide();
                    label_point.Hide();
                    label_yuan.Hide();
                    break;
                default:
                    break;
            }


            Text = "商品信息——" + sellingInfo.commodity_name;
            text_commodityName.Text = sellingInfo.commodity_name;
            text_catagory.Text      = sellingInfo.commodity_category;
            text_sellerName.Text    = sellingInfo.seller_name;
            text_platformName.Text  = sellingInfo.platform_name;
            text_price.Text         = sellingInfo.price + "元";
            text_produceDate.Text   = sellingInfo.produce_date;
            text_life.Text          = sellingInfo.shelf_life + "天";
            text_address.Text       = sellingInfo.produce_address;
            text_description.Text   = sellingInfo.description;
        }


        public SellingPanel(SellingInfo sellingInfo, E_RelationType userType, Action<SellingInfo> AddToFavorites, Action<SellingInfo> RemoveFromFavorites) : this(sellingInfo, userType)
        {
            this.AddToFavorites += AddToFavorites;
            this.RemoveFromFavorites += RemoveFromFavorites;
        }

        public SellingPanel(SellingInfo sellingInfo, E_RelationType userType, Action<SellingInfo> RemoveFromSellingList) : this(sellingInfo, userType)
        {
            this.RemoveFromSellingList += RemoveFromSellingList;
        }

        /// <summary>
        /// 点击返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 收藏
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_collect_Click(object sender, EventArgs e)
        {
            if (text_priceFloorInt.Text.Length == 0)
            {
                MessageBox.Show("价格下限不能为空");
                return;
            }
            if (text_priceFloorDec.Text.Length != 2)
            {
                MessageBox.Show("价格下限的小数部分不完整");
                return;
            }

            string priceFloor = text_priceFloorInt.Text + "." + text_priceFloorDec.Text;
            //更新收藏夹
            sellingInfo.priceFloor = priceFloor;
            AddToFavorites(sellingInfo);
            //更新商品面板
            btn_cancel.Show();
            btn_collect.Hide();
            text_priceFloorInt.ReadOnly = true;
            text_priceFloorDec.ReadOnly = true;
        }

        /// <summary>
        /// 取消收藏
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            RemoveFromFavorites(sellingInfo);
            btn_cancel.Hide();
            btn_collect.Show();
            text_priceFloorInt.ReadOnly = false;
            text_priceFloorDec.ReadOnly = false;
        }

        private void text_priceFloorInt_KeyPress(object sender, KeyPressEventArgs e)
        {
            //如果输入的不是退格和数字，则屏蔽输入
            if (!(e.KeyChar == '\b' || (e.KeyChar >= '0' && e.KeyChar <= '9')))
            {
                e.Handled = true;
            }
        }

        private void text_priceFloorDec_KeyPress(object sender, KeyPressEventArgs e)
        {
            //如果输入的不是退格和数字，则屏蔽输入
            if (!(e.KeyChar == '\b' || (e.KeyChar >= '0' && e.KeyChar <= '9')))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 显示历史价格
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_showHistory_Click(object sender, EventArgs e)
        {
            new ChartPanel(sellingInfo, E_ChartType.HistoryPrices).Show();
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (Manager.Instance.RemoveFromShelves(sellingInfo))
            {
                RemoveFromSellingList?.Invoke(sellingInfo);
                MessageBox.Show("Remove sucessful!");
                Close();
            }
        }
    }
}
