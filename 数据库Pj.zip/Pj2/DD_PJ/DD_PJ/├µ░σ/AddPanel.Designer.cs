﻿namespace pj_DBD
{
    partial class AddPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_name = new System.Windows.Forms.Label();
            this.label_category = new System.Windows.Forms.Label();
            this.text_commodity = new System.Windows.Forms.TextBox();
            this.combo_category = new System.Windows.Forms.ComboBox();
            this.btn_return = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("等线", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_name.Location = new System.Drawing.Point(62, 91);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(50, 21);
            this.label_name.TabIndex = 82;
            this.label_name.Text = "名称";
            // 
            // label_category
            // 
            this.label_category.AutoSize = true;
            this.label_category.Font = new System.Drawing.Font("等线", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_category.Location = new System.Drawing.Point(398, 91);
            this.label_category.Name = "label_category";
            this.label_category.Size = new System.Drawing.Size(50, 21);
            this.label_category.TabIndex = 83;
            this.label_category.Text = "种类";
            // 
            // text_commodity
            // 
            this.text_commodity.Font = new System.Drawing.Font("等线", 10.8F);
            this.text_commodity.Location = new System.Drawing.Point(118, 89);
            this.text_commodity.Name = "text_commodity";
            this.text_commodity.Size = new System.Drawing.Size(180, 26);
            this.text_commodity.TabIndex = 84;
            // 
            // combo_category
            // 
            this.combo_category.Font = new System.Drawing.Font("等线", 10.8F);
            this.combo_category.FormattingEnabled = true;
            this.combo_category.Location = new System.Drawing.Point(454, 89);
            this.combo_category.Name = "combo_category";
            this.combo_category.Size = new System.Drawing.Size(180, 27);
            this.combo_category.TabIndex = 85;
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 11F);
            this.btn_return.Location = new System.Drawing.Point(347, 233);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(105, 36);
            this.btn_return.TabIndex = 86;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // btn_add
            // 
            this.btn_add.Font = new System.Drawing.Font("等线", 11F);
            this.btn_add.Location = new System.Drawing.Point(266, 163);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(105, 36);
            this.btn_add.TabIndex = 87;
            this.btn_add.Text = "添 加";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("等线", 11F);
            this.btn_delete.Location = new System.Drawing.Point(428, 163);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(105, 36);
            this.btn_delete.TabIndex = 88;
            this.btn_delete.Text = "删除";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // AddPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 281);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.combo_category);
            this.Controls.Add(this.text_commodity);
            this.Controls.Add(this.label_category);
            this.Controls.Add(this.label_name);
            this.Name = "AddPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddPanel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_category;
        private System.Windows.Forms.TextBox text_commodity;
        private System.Windows.Forms.ComboBox combo_category;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
    }
}