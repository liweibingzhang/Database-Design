﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DD_PJ
{
    public partial class RegisertPanel : Form
    {
        /// <summary>
        /// 登入类型
        /// </summary>
        E_RelationType userType;

        /// <summary>
        /// 登入面板
        /// </summary>
        LoginPanel loginPanel;

        /// <summary>
        /// 密码是否显示
        /// </summary>
        bool isPwdShown = false;

        /// <summary>
        /// 密码掩码
        /// </summary>
        char C => isPwdShown ? '\0' : '*';

        /// <summary>
        /// 所有用户/商家的名称
        /// </summary>
        List<string> names;

        public RegisertPanel(E_RelationType userType)
        {
            InitializeComponent();
            this.userType = userType;

            names = Manager.Instance.GetNames(userType);

            switch (userType)
            {
                case E_RelationType.User:
                    label_title.Text = "用户注册";
                    label_name.Show();
                    text_name.Show();
                    label_name.Text = "用户名";
                    break;
                case E_RelationType.Seller:
                    label_title.Text = "商家注册";
                    label_name.Show();
                    text_name.Show();
                    label_name.Text = "商家名";
                    break;
                default:
                    break;
            }
            Text = label_title.Text;
        }

        public RegisertPanel(E_RelationType type, LoginPanel loginPanel) : this(type)
        {
            this.loginPanel = loginPanel;
        }

        /// <summary>
        /// 注册的方法
        /// </summary>
        void Register()
        {
            string warning1 = "";
            string warning2 = "";
            switch (userType)
            {
                case E_RelationType.User:
                    warning1 = "用户名不能为空";
                    warning2 = "用户名已被注册";
                    break;
                case E_RelationType.Seller:
                    warning1 = "商家名不能为空";
                    warning2 = "商家名已被注册";
                    break;
                default:
                    break;
            }

            string name = text_name.Text;
            string password = text_password.Text;
            //判断用户名是否为空
            if (name.Length == 0)
            {
                MessageBox.Show(warning1);
                return;
            }
            //判断用户名是否重复
            if (names.Contains(name))
            {
                MessageBox.Show(warning2);
                return;
            }
            //判断密码是否有中文字符
            if (CheckChinese(password))
            {
                MessageBox.Show("密码中不能存在中文字符");
                return;
            }
            //判断密码长度是否小于3
            if (password.Length < 3)
            {
                MessageBox.Show("密码的长度至少为3个字符");
                return;
            }

            //从管理员处注册
            if (Manager.Instance.Register(name, password, userType))
                MessageBox.Show("Register successful!");
            Close();
        }

        /// <summary>
        /// 检查密码输入是否存在中文
        /// </summary>
        /// <returns></returns>
        public static bool CheckChinese(string text)
        {
            Regex re = new Regex(@"[\u4e00-\u9fa5]+");
            if (re.IsMatch(text))
            {
                return true;
            }

            return false;
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            Register();
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void RegisertPanel_FormClosed(object sender, FormClosedEventArgs e)
        {
            loginPanel?.Show();
        }

        private void btn_showPwd_Click(object sender, EventArgs e)
        {
            isPwdShown = !isPwdShown;
            text_password.PasswordChar = C;
        }
    }
}
