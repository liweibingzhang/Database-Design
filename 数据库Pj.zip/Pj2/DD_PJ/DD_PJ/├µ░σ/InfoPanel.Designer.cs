﻿namespace pj_DBD
{
    partial class InfoPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label_tip = new System.Windows.Forms.Label();
            this.listBox_info = new System.Windows.Forms.ListBox();
            this.btn_return = new System.Windows.Forms.Button();
            this.text_commodity = new System.Windows.Forms.TextBox();
            this.text_seller = new System.Windows.Forms.TextBox();
            this.text_platform = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(543, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 19);
            this.label2.TabIndex = 66;
            this.label2.Text = "选择平台";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(304, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 19);
            this.label3.TabIndex = 64;
            this.label3.Text = "选择商家";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(65, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 19);
            this.label1.TabIndex = 63;
            this.label1.Text = "选择商品";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader4,
            this.columnHeader2,
            this.columnHeader3});
            this.listView1.Font = new System.Drawing.Font("等线", 10.8F);
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(59, 113);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(683, 34);
            this.listView1.TabIndex = 60;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "商品名";
            this.columnHeader1.Width = 128;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "商家";
            this.columnHeader4.Width = 128;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "销售平台";
            this.columnHeader2.Width = 128;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "售价";
            this.columnHeader3.Width = 128;
            // 
            // label_tip
            // 
            this.label_tip.AutoSize = true;
            this.label_tip.Font = new System.Drawing.Font("等线", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_tip.ForeColor = System.Drawing.Color.Blue;
            this.label_tip.Location = new System.Drawing.Point(609, 95);
            this.label_tip.Name = "label_tip";
            this.label_tip.Size = new System.Drawing.Size(127, 15);
            this.label_tip.TabIndex = 59;
            this.label_tip.Text = "双击查看商品详情";
            // 
            // listBox_info
            // 
            this.listBox_info.Font = new System.Drawing.Font("等线", 10.8F);
            this.listBox_info.FormattingEnabled = true;
            this.listBox_info.ItemHeight = 19;
            this.listBox_info.Location = new System.Drawing.Point(59, 146);
            this.listBox_info.Name = "listBox_info";
            this.listBox_info.Size = new System.Drawing.Size(683, 194);
            this.listBox_info.TabIndex = 58;
            this.listBox_info.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox_sellingInfo_MouseDoubleClick);
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 11F);
            this.btn_return.Location = new System.Drawing.Point(362, 379);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(87, 36);
            this.btn_return.TabIndex = 57;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // text_commodity
            // 
            this.text_commodity.Font = new System.Drawing.Font("等线", 10.8F);
            this.text_commodity.Location = new System.Drawing.Point(69, 59);
            this.text_commodity.Name = "text_commodity";
            this.text_commodity.Size = new System.Drawing.Size(180, 26);
            this.text_commodity.TabIndex = 67;
            this.text_commodity.TextChanged += new System.EventHandler(this.text_commodity_TextChanged);
            // 
            // text_seller
            // 
            this.text_seller.Font = new System.Drawing.Font("等线", 10.8F);
            this.text_seller.Location = new System.Drawing.Point(308, 59);
            this.text_seller.Name = "text_seller";
            this.text_seller.Size = new System.Drawing.Size(180, 26);
            this.text_seller.TabIndex = 68;
            this.text_seller.TextChanged += new System.EventHandler(this.text_seller_TextChanged);
            // 
            // text_platform
            // 
            this.text_platform.Font = new System.Drawing.Font("等线", 10.8F);
            this.text_platform.Location = new System.Drawing.Point(547, 59);
            this.text_platform.Name = "text_platform";
            this.text_platform.Size = new System.Drawing.Size(180, 26);
            this.text_platform.TabIndex = 69;
            this.text_platform.TextChanged += new System.EventHandler(this.text_platform_TextChanged);
            // 
            // InfoPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.text_platform);
            this.Controls.Add(this.text_seller);
            this.Controls.Add(this.text_commodity);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label_tip);
            this.Controls.Add(this.listBox_info);
            this.Controls.Add(this.btn_return);
            this.Name = "InfoPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "3";
            this.Activated += new System.EventHandler(this.InfoPanel_Activated);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label_tip;
        private System.Windows.Forms.ListBox listBox_info;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.TextBox text_commodity;
        private System.Windows.Forms.TextBox text_seller;
        private System.Windows.Forms.TextBox text_platform;
    }
}