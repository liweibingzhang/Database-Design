﻿using pj_DBD;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DD_PJ
{
    public partial class UserPanel : Form
    {
        /// <summary>
        /// 初始面板
        /// </summary>
        InitialPanel initialPanel;

        /// <summary>
        /// 用户信息
        /// </summary>
        UserInfo userInfo;

        /// <summary>
        /// 在售商品信息
        /// </summary>
        List<SellingInfo> sellingInfoList;

        /// <summary>
        /// 用户的收藏
        /// </summary>
        List<SellingInfo> favorites = new List<SellingInfo>();

        /// <summary>
        /// 用户的消息
        /// </summary>
        List<UserMessage> messages;

        public UserPanel(UserInfo userInfo)
        {
            InitializeComponent();
            btn_save.Hide();
            btn_cancel.Hide();
            dateTime_birthDate.Hide();
            btn_favorite.Hide();
            btn_message.Hide();
            btn_showCommodities.Hide();
            label_notRead.Hide();
            this.userInfo = userInfo;

            Text = "用户信息——" + userInfo.user_name;
            text_fullname.Text = userInfo.fullname;
            text_password.Text = userInfo.password;
            text_phone.Text = userInfo.phone_number;
            text_birthDate.Text = userInfo.birth_date;
            text_address.Text = userInfo.home_address;
        }

        public UserPanel(InitialPanel initialPanel, UserInfo userInfo) : this(userInfo)
        {
            this.initialPanel = initialPanel;
            btn_delete.Hide();
            btn_favorite.Show();
            btn_message.Show();
            btn_showCommodities.Show();
            //添加在售商品的信息
            sellingInfoList = Manager.Instance.GetSellingInfo();

            //添加收藏夹信息
            Manager.Instance.GetUserFavorites(userInfo.ID, favorites, sellingInfoList);
        }

        void AddToFavorites(SellingInfo favorite)
        {
            if (Manager.Instance.AddToFavorites(userInfo.ID, favorite))
            {
                MessageBox.Show("Collect sucessful!");
                favorite.isFavorite = true;
                favorites.Add(favorite);
            }
        }

        void RemoveFromFavorites(SellingInfo notFavorite)
        {
            Manager.Instance.RemoveFromFavorites(userInfo.ID, notFavorite);
            notFavorite.isFavorite = false;
            favorites.Remove(notFavorite);
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (text_password.Text.Length < 3)
            {
                MessageBox.Show("密码的长度至少为3个字符");
                return;
            }
            if (RegisertPanel.CheckChinese(text_password.Text))
            {
                MessageBox.Show("密码中不能存在中文字符");
                return;
            }
            btn_edit.Show();
            btn_save.Hide();
            btn_cancel.Hide();
            dateTime_birthDate.Hide();
            text_fullname.ReadOnly  = true;
            text_password.ReadOnly  = true;
            text_phone.ReadOnly     = true;
            text_birthDate.ReadOnly = true;
            text_address.ReadOnly   = true;

            //设置用户信息
            userInfo.fullname     = text_fullname.Text;
            userInfo.password     = text_password.Text;
            userInfo.phone_number = text_phone.Text;
            userInfo.birth_date   = dateTime_birthDate.Text;
            userInfo.birth_date   = Convert.ToDateTime(dateTime_birthDate.Text).ToString("yyyy-MM-dd");
            userInfo.home_address = text_address.Text;

            //在数据库中更新用户信息
            Manager.Instance.UpdateUserInfo(userInfo);
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            btn_edit.Show();
            btn_save.Hide();
            btn_cancel.Hide();
            dateTime_birthDate.Hide();
            text_fullname.ReadOnly  = true;
            text_password.ReadOnly  = true;
            text_phone.ReadOnly     = true;
            text_birthDate.ReadOnly = true;
            text_address.ReadOnly   = true;

            text_fullname.Text  = userInfo.fullname;
            text_password.Text  = userInfo.password;
            text_phone.Text     = userInfo.phone_number;
            text_birthDate.Text = userInfo.birth_date;
            text_address.Text   = userInfo.home_address;
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            btn_edit.Hide();
            btn_save.Show();
            btn_cancel.Show();
            dateTime_birthDate.Show();
            text_fullname.ReadOnly  = false;
            text_password.ReadOnly  = false;
            text_phone.ReadOnly     = false;
            text_birthDate.ReadOnly = false;
            text_address.ReadOnly   = false;

            dateTime_birthDate.Text = userInfo.birth_date;
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void UserPanel_FormClosed(object sender, FormClosedEventArgs e)
        {
            initialPanel?.Show();
        }

        private void text_phone_KeyPress(object sender, KeyPressEventArgs e)
        {
            //如果输入的不是退格和数字，则屏蔽输入
            if (!(e.KeyChar == '\b' || (e.KeyChar >= '0' && e.KeyChar <= '9')))
            {
                e.Handled = true;
            }
        }

        private void btn_message_Click(object sender, EventArgs e)
        {
            new InfoPanel(messages, E_RelationType.User).Show();
        }

        private void btn_favorites_Click(object sender, EventArgs e)
        {
            new InfoPanel(favorites, E_RelationType.User, AddToFavorites, RemoveFromFavorites).Show();
        }

        private void btn_showCommodities_Click(object sender, EventArgs e)
        {
            new InfoPanel(sellingInfoList, E_RelationType.User, AddToFavorites, RemoveFromFavorites).Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (Manager.Instance.DeleteRecord(userInfo.ID, E_RelationType.User, "ID"))
            {
                MessageBox.Show("Delete successful!");
                Close();
            }
        }

        private void UserPanel_Activated(object sender, EventArgs e)
        {
            //加载消息
            messages = Manager.Instance.GetUserMessages(userInfo.ID);
            foreach (UserMessage message in messages)
            {
                if (message.state == "未读")
                {
                    label_notRead.Show();
                    return;
                }
            }
            label_notRead.Hide();
        }

        private void btn_priceDiff_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.PriceDifferences).Show();
        }

        private void btn_priceRange_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.HistoryPriceRange).Show();
        }
    }
}
