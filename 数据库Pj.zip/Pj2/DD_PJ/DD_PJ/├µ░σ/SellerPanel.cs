﻿using MySqlX.XDevAPI.Common;
using pj_DBD;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DD_PJ
{
    /// <summary>
    /// 商家面板
    /// </summary>
    public partial class SellerPanel : Form
    {
        /// <summary>
        /// 初始面板
        /// </summary>
        InitialPanel initialPanel;

        /// <summary>
        /// 商家信息
        /// </summary>
        SellerInfo sellerInfo;

        /// <summary>
        /// 在售商品信息
        /// </summary>
        List<SellingInfo> sellingInfoList;

        public SellerPanel(SellerInfo sellerInfo)
        {
            InitializeComponent();
            btn_save.Hide();
            btn_cancel.Hide();
            btn_selling.Hide();
            btn_publish.Hide();
            this.sellerInfo = sellerInfo;


            Text = "商家信息——" + sellerInfo.seller_name;
            text_fullname.Text    = sellerInfo.fullname;
            text_password.Text    = sellerInfo.password;
            text_address.Text     = sellerInfo.address;
            text_description.Text = sellerInfo.description;
            text_phone.Text       = sellerInfo.phone_number;
        }

        public SellerPanel(InitialPanel initialPanel, SellerInfo sellerInfo) : this(sellerInfo)
        {
            this.initialPanel = initialPanel;
            btn_selling.Show();
            btn_publish.Show();
            btn_delete.Hide();
            sellingInfoList = Manager.Instance.GetSellingInfo(sellerInfo.ID);
        }

        void RemoveFromSellingList(SellingInfo sellingInfo)
        {
            sellingInfoList.Remove(sellingInfo);
        }

        /// <summary>
        /// 每次面板关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SellerPanel_FormClosed(object sender, FormClosedEventArgs e)
        {
            initialPanel?.Show();
        }

        /// <summary>
        /// 点击返回
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// 点击保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (text_password.Text.Length < 3)
            {
                MessageBox.Show("密码的长度至少为3个字符");
                return;
            }
            if (RegisertPanel.CheckChinese(text_password.Text))
            {
                MessageBox.Show("密码中不能存在中文字符");
                return;
            }
            btn_edit.Show();
            btn_save.Hide();
            btn_cancel.Hide();
            text_fullname.ReadOnly    = true;
            text_password.ReadOnly    = true;
            text_address.ReadOnly     = true;
            text_description.ReadOnly = true;
            text_phone.ReadOnly       = true;

            //设置商家信息
            sellerInfo.fullname     = text_fullname.Text;
            sellerInfo.password     = text_password.Text;
            sellerInfo.address      = text_address.Text;
            sellerInfo.description  = text_description.Text;
            sellerInfo.phone_number = text_phone.Text;

            //在数据库中更新商家信息
            Manager.Instance.UpdateSellerInfo(sellerInfo);
        }

        /// <summary>
        /// 点击取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            btn_edit.Show();
            btn_save.Hide();
            btn_cancel.Hide();
            text_fullname.ReadOnly    = true;
            text_password.ReadOnly    = true;
            text_address.ReadOnly     = true;
            text_description.ReadOnly = true;
            text_phone.ReadOnly       = true;

            text_fullname.Text    = sellerInfo.fullname;
            text_password.Text    = sellerInfo.password;
            text_address.Text     = sellerInfo.address;
            text_description.Text = sellerInfo.description;
            text_phone.Text       = sellerInfo.phone_number;
        }

        /// <summary>
        /// 点击编辑
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_edit_Click(object sender, EventArgs e)
        {
            btn_edit.Hide();
            btn_save.Show();
            btn_cancel.Show();
            text_fullname.ReadOnly    = false;
            text_password.ReadOnly    = false;
            text_address.ReadOnly     = false;
            text_description.ReadOnly = false;
            text_phone.ReadOnly       = false;
        }

        /// <summary>
        /// 点击发布商品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_publish_Click(object sender, EventArgs e)
        {
            new PublishingPanel(sellerInfo.seller_name, sellingInfoList).Show();
        }

        private void btn_selling_Click(object sender, EventArgs e)
        {
            new InfoPanel(sellingInfoList, E_RelationType.Seller, RemoveFromSellingList).Show();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (Manager.Instance.DeleteRecord(sellerInfo.ID, E_RelationType.Seller, "ID"))
            {
                MessageBox.Show("Delete successful!");
                Close();
            }
        }
    }
}
