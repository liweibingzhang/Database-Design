﻿using DD_PJ;
using MySqlX.XDevAPI.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pj_DBD
{
    public partial class InfoPanel : Form
    {
        /// <summary>
        /// 用户类型
        /// </summary>
        E_RelationType userType;

        /// <summary>
        /// 信息
        /// </summary>
        IList infoList;

        /// <summary>
        /// 当前搜索到的信息
        /// </summary>
        IList result;

        /// <summary>
        /// 添加到用户收藏夹的事件
        /// </summary>
        event Action<SellingInfo> AddToFavorites;

        /// <summary>
        /// 将商品移出用户收藏夹的事件
        /// </summary>
        event Action<SellingInfo> RemoveFromFavorites;

        /// <summary>
        /// 将商品移出商家的在售商品列表
        /// </summary>
        event Action<SellingInfo> RemoveFromSellingList;

        /// <summary>
        /// 是否按售价升序排列
        /// </summary>
        bool isAsc = false;

        public InfoPanel(IList infoList, E_RelationType userType)
        {
            InitializeComponent();
            this.infoList = infoList;
            this.userType = userType;

            if (infoList is List<SellingInfo>)
            {
                Text = "商品信息";
                listView1.Columns[0].Text = "商品名";
                listView1.Columns[1].Text = "商家";
                listView1.Columns[2].Text = "销售平台";
                listView1.Columns[3].Text = "售价";
                label_tip.Text = "双击查看商品信息";
            }
            else if (infoList is List<UserInfo>)
            {
                text_commodity.Hide();
                text_seller.Hide();
                text_platform.Hide();
                label1.Hide();
                label2.Hide();
                label3.Hide();
                Text = "用户信息";
                listView1.Columns[0].Text = "ID";
                listView1.Columns[1].Text = "用户名";
                listView1.Columns[2].Text = "全名";
                listView1.Columns[3].Text = "电话";
                label_tip.Text = "双击查看用户信息";
            }
            else if (infoList is List<SellerInfo>)
            {
                text_commodity.Hide();
                text_seller.Hide();
                text_platform.Hide();
                label1.Hide();
                label2.Hide();
                label3.Hide();
                Text = "商家信息";
                listView1.Columns[0].Text = "ID";
                listView1.Columns[1].Text = "商家名";
                listView1.Columns[2].Text = "地址";
                listView1.Columns[3].Text = "联系电话";
                label_tip.Text = "双击查看商家信息";
            }
            else if (infoList is List<(string id, string name)>)
            {
                text_commodity.Hide();
                text_seller.Hide();
                text_platform.Hide();
                label1.Hide();
                label2.Hide();
                label3.Hide();
                Text = "平台信息";
                listView1.Columns[0].Text = "ID";
                listView1.Columns[1].Text = "平台名";
                listView1.Columns[2].Text = "";
                listView1.Columns[3].Text = "";
                label_tip.Text = "";
            }
            else if (infoList is List<UserMessage>)
            {
                text_commodity.Hide();
                text_seller.Hide();
                text_platform.Hide();
                label1.Hide();
                label2.Hide();
                label3.Hide();
                Text = "消息列表";
                listView1.Columns[0].Text = "类型";
                listView1.Columns[1].Text = "已读/未读";
                listView1.Columns[2].Text = "时间";
                listView1.Columns[3].Text = "";
                label_tip.Text = "双击查看消息内容";
            }
            else if (infoList is List<CommodityInfo>)
            {
                text_commodity.Hide();
                text_seller.Hide();
                text_platform.Hide();
                label1.Hide();
                label2.Hide();
                label3.Hide();
                Text = "商品列表";
                listView1.Columns[0].Text = "ID";
                listView1.Columns[1].Text = "商品名";
                listView1.Columns[2].Text = "种类";
                listView1.Columns[3].Text = "";
                label_tip.Text = "";
            }
        }

        public InfoPanel(List<SellingInfo> sellingInfoList, E_RelationType userType, Action<SellingInfo> AddToFavorites, Action<SellingInfo> RemoveFromFavorites) : this(sellingInfoList, userType)
        {
            this.AddToFavorites += AddToFavorites;
            this.RemoveFromFavorites += RemoveFromFavorites;
        }

        public InfoPanel(List<SellingInfo> sellingInfoList, E_RelationType userType, Action<SellingInfo> RemoveFromSellingList) : this(sellingInfoList, userType)
        {
            this.RemoveFromSellingList += RemoveFromSellingList;
        }

        /// <summary>
        /// 搜索用户当前输入的内容
        /// </summary>
        void Search()
        {
            listBox_info.Items.Clear();
            string commodityName = text_commodity.Text;
            string sellerName = text_seller.Text;
            string platformName = text_platform.Text;

            IList result1 = new List<SellingInfo>();
            if (commodityName.Length != 0)
            {
                foreach (SellingInfo info in infoList)
                {
                    if (info.commodity_name.Contains(commodityName))
                    {
                        result1.Add(info);
                    }
                }
            }
            else
                result1 = infoList;
            IList result2 = new List<SellingInfo>();
            if (sellerName.Length != 0)
            {
                foreach (SellingInfo info in result1)
                {
                    if (info.seller_name.Contains(sellerName))
                    {
                        result2.Add(info);
                    }
                }
            }
            else
                result2 = result1;
            result = new List<SellingInfo>();
            if (platformName.Length != 0)
            {
                foreach (SellingInfo info in result2)
                {
                    if (info.platform_name.Contains(platformName))
                    {
                        result.Add(info);
                    }
                }
            }
            else
                result = result2;
            foreach (SellingInfo info in result)
            {
                listBox_info.Items.Add(info);
            }
        }

        private void listBox_sellingInfo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int index = listBox_info.IndexFromPoint(e.Location);

            if (index != ListBox.NoMatches)
            {
                if (listBox_info.SelectedItem is SellingInfo)
                {
                    switch (userType)
                    {
                        case E_RelationType.User:
                            new SellingPanel(listBox_info.SelectedItem as SellingInfo, E_RelationType.User, AddToFavorites, RemoveFromFavorites).Show();
                            break;
                        case E_RelationType.Seller:
                            new SellingPanel(listBox_info.SelectedItem as SellingInfo, E_RelationType.Seller, RemoveFromSellingList).Show();
                            break;
                        case E_RelationType.Administrator:
                            new SellingPanel(listBox_info.SelectedItem as SellingInfo, E_RelationType.Administrator).Show();
                            break;
                        default:
                            break;
                    }
                }
                else if (listBox_info.SelectedItem is UserInfo)
                {
                    new UserPanel(listBox_info.SelectedItem as UserInfo).Show();
                }
                else if (listBox_info.SelectedItem is SellerInfo)
                {
                    new SellerPanel(listBox_info.SelectedItem as SellerInfo).Show();
                }
                else if (listBox_info.SelectedItem is UserMessage)
                {
                    UserMessage msg = listBox_info.SelectedItem as UserMessage;
                    msg.state = "已读";
                    Manager.Instance.SetMessageRead(msg.ID);
                    MessageBox.Show(msg.content);
                }
            }
            else
            {
                listBox_info.SelectedIndex = -1;
            }
        }

        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column != 3)
                return;
            if (result == null)
                return;
            isAsc = !isAsc;
            //升序排列
            if (isAsc)
            {
                (result as List<SellingInfo>).Sort((a, b) => float.Parse(a.price) >= float.Parse(b.price) ? 1 : -1);
            }
            //降序排列
            else
            {
                (result as List<SellingInfo>).Sort((a, b) => float.Parse(a.price) < float.Parse(b.price) ? 1 : -1);
            }
            listBox_info.Items.Clear();
            foreach (SellingInfo info in result)
            {
                listBox_info.Items.Add(info);
            }
        }

        private void text_commodity_TextChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void text_seller_TextChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void text_platform_TextChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void InfoPanel_Activated(object sender, EventArgs e)
        {
            listBox_info.Items.Clear();
            if (infoList is List<SellingInfo>)
            {
                result = new List<SellingInfo>();
                foreach (SellingInfo info in infoList)
                {
                    if (info.priceFloor == null)
                        info.priceFloor = info.price;
                    listBox_info.Items.Add(info);
                    result.Add(info);
                }
            }
            else if (infoList is List<UserInfo>)
            {
                foreach (UserInfo info in infoList)
                {
                    listBox_info.Items.Add(info);
                }
            }
            else if (infoList is List<SellerInfo>)
            {
                foreach (SellerInfo info in infoList)
                {
                    listBox_info.Items.Add(info);
                }
            }
            else if (infoList is List<UserMessage>)
            {
                foreach (UserMessage info in infoList)
                {
                    listBox_info.Items.Add(info);
                }
            }
            else if (infoList is List<CommodityInfo>)
            {
                foreach (CommodityInfo info in infoList)
                {
                    listBox_info.Items.Add(info);
                }
            }
            else if (infoList is List<(string id, string name)>)
            {
                foreach ((string id, string name) info in infoList)
                {
                    string str = "";
                    str += info.id + "\r\t\r\t ";
                    str += info.name + "\r\t\r\t ";
                    listBox_info.Items.Add(str);
                }
            }
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
