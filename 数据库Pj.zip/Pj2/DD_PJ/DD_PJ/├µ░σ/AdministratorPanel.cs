﻿using DD_PJ;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pj_DBD
{
    public partial class AdministratorPanel : Form
    {
        InitialPanel initialPanel;

        List<UserInfo> userInfoList;

        List<SellerInfo> sellerInfoList;

        List<SellingInfo> sellingInfoList;

        List<CommodityInfo> commodityInfoList;

        List<(string id, string name)> platformInfoList;

        public AdministratorPanel(InitialPanel initialPanel)
        {
            InitializeComponent();
            this.initialPanel = initialPanel;

            Text = "管理员";
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AdministratorPanel_FormClosed(object sender, FormClosedEventArgs e)
        {
            initialPanel.Show();
        }

        private void btn_user_Click(object sender, EventArgs e)
        {
            new InfoPanel(userInfoList, E_RelationType.Administrator).Show();
        }

        private void btn_seller_Click(object sender, EventArgs e)
        {
            new InfoPanel(sellerInfoList, E_RelationType.Administrator).Show();
        }

        private void btn_platform_Click(object sender, EventArgs e)
        {
            new InfoPanel(platformInfoList, E_RelationType.Administrator).Show();
        }

        private void btn_commodity_Click(object sender, EventArgs e)
        {
            new InfoPanel(commodityInfoList, E_RelationType.Administrator).Show();
        }

        private void btn_selling_Click(object sender, EventArgs e)
        {
            new InfoPanel(sellingInfoList, E_RelationType.Administrator).Show();
        }

        private void btn_addUser_Click(object sender, EventArgs e)
        {
            new RegisertPanel(E_RelationType.User).Show();
        }

        private void btn_addSeller_Click(object sender, EventArgs e)
        {
            new RegisertPanel(E_RelationType.Seller).Show();
        }

        private void btn_addPlatform_Click(object sender, EventArgs e)
        {
            new AddPanel(E_RelationType.Platform).Show();
        }

        private void btn_addCommodity_Click(object sender, EventArgs e)
        {
            new AddPanel(E_RelationType.Commodity).Show();
        }

        private void btn_publish_Click(object sender, EventArgs e)
        {
            new PublishingPanel(sellingInfoList).Show();
        }

        private void AdministratorPanel_Activated(object sender, EventArgs e)
        {
            userInfoList = Manager.Instance.GetUsersInfo();
            sellerInfoList = Manager.Instance.GetSellersInfo();
            platformInfoList = Manager.Instance.GetPlatformsInfo();
            sellingInfoList = Manager.Instance.GetSellingInfo();
            commodityInfoList = Manager.Instance.GetCommoditiesInfo();
        }

        private void btn_favoriteDistribution_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.FavoritesDistribution).Show();
        }

        private void btn_priceRange_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.HistoryPriceRange).Show();
        }

        private void btn_priceDiff_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.PriceDifferences).Show();
        }

        private void btn_favoriteCount_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.FavoriteCount).Show();
        }

        private void btn_userFavorites_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.UserFavorites).Show();
        }

        private void btn_userPriceInclination_Click(object sender, EventArgs e)
        {
            new ChartPanel(E_ChartType.PriceInclination).Show();
        }
    }
}
