﻿namespace DD_PJ
{
    partial class LoginPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_title = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_password = new System.Windows.Forms.Label();
            this.text_password = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_return = new System.Windows.Forms.Button();
            this.linkLabel_register = new System.Windows.Forms.LinkLabel();
            this.btn_showPwd = new System.Windows.Forms.Button();
            this.combo_name = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label_title
            // 
            this.label_title.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_title.BackColor = System.Drawing.SystemColors.Control;
            this.label_title.Font = new System.Drawing.Font("等线", 20F);
            this.label_title.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_title.Location = new System.Drawing.Point(252, 63);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(311, 36);
            this.label_title.TabIndex = 1;
            this.label_title.Text = "用户登入";
            this.label_title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.BackColor = System.Drawing.SystemColors.Control;
            this.label_name.Font = new System.Drawing.Font("等线", 13F);
            this.label_name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_name.Location = new System.Drawing.Point(197, 162);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(76, 23);
            this.label_name.TabIndex = 2;
            this.label_name.Text = "用户名";
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.BackColor = System.Drawing.SystemColors.Control;
            this.label_password.Font = new System.Drawing.Font("等线", 13F);
            this.label_password.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_password.Location = new System.Drawing.Point(197, 249);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(76, 23);
            this.label_password.TabIndex = 3;
            this.label_password.Text = "密　码";
            // 
            // text_password
            // 
            this.text_password.Font = new System.Drawing.Font("等线", 11F);
            this.text_password.Location = new System.Drawing.Point(292, 249);
            this.text_password.MaxLength = 20;
            this.text_password.Name = "text_password";
            this.text_password.PasswordChar = '*';
            this.text_password.Size = new System.Drawing.Size(277, 27);
            this.text_password.TabIndex = 5;
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("等线", 12F);
            this.btn_login.Location = new System.Drawing.Point(258, 357);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(97, 42);
            this.btn_login.TabIndex = 6;
            this.btn_login.Text = "登 入";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 12F);
            this.btn_return.Location = new System.Drawing.Point(447, 357);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(97, 42);
            this.btn_return.TabIndex = 7;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // linkLabel_register
            // 
            this.linkLabel_register.AutoSize = true;
            this.linkLabel_register.Location = new System.Drawing.Point(331, 304);
            this.linkLabel_register.Name = "linkLabel_register";
            this.linkLabel_register.Size = new System.Drawing.Size(142, 15);
            this.linkLabel_register.TabIndex = 8;
            this.linkLabel_register.TabStop = true;
            this.linkLabel_register.Text = "没有账户？点此创建";
            this.linkLabel_register.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_register_LinkClicked);
            // 
            // btn_showPwd
            // 
            this.btn_showPwd.Font = new System.Drawing.Font("等线", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_showPwd.Location = new System.Drawing.Point(568, 249);
            this.btn_showPwd.Name = "btn_showPwd";
            this.btn_showPwd.Size = new System.Drawing.Size(54, 30);
            this.btn_showPwd.TabIndex = 18;
            this.btn_showPwd.Text = "显示";
            this.btn_showPwd.UseVisualStyleBackColor = true;
            this.btn_showPwd.Click += new System.EventHandler(this.btn_showPwd_Click);
            // 
            // combo_name
            // 
            this.combo_name.Font = new System.Drawing.Font("等线", 11F);
            this.combo_name.FormattingEnabled = true;
            this.combo_name.Location = new System.Drawing.Point(292, 162);
            this.combo_name.MaxLength = 20;
            this.combo_name.Name = "combo_name";
            this.combo_name.Size = new System.Drawing.Size(277, 27);
            this.combo_name.TabIndex = 19;
            // 
            // LoginPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.combo_name);
            this.Controls.Add(this.btn_showPwd);
            this.Controls.Add(this.linkLabel_register);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.text_password);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.label_title);
            this.Name = "LoginPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LoginPanel";
            this.Activated += new System.EventHandler(this.LoginPanel_Activated);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoginPanel_FormClosed);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.LoginPanel_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.TextBox text_password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.LinkLabel linkLabel_register;
        private System.Windows.Forms.Button btn_showPwd;
        private System.Windows.Forms.ComboBox combo_name;
    }
}