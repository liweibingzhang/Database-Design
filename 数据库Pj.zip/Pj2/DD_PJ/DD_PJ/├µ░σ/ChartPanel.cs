﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DD_PJ
{
    /// <summary>
    /// 时间跨度
    /// </summary>
    public enum E_Timespan
    {
        Week = 7,
        Month = 30,
        Year = 365
    }

    public enum E_ChartType
    {
        FavoriteCount,
        HistoryPrices,
        FavoritesDistribution,
        HistoryPriceRange,
        PriceDifferences,
        UserFavorites,
        PriceInclination
    }

    public partial class ChartPanel : Form
    {
        /// <summary>
        /// 要显示历史价格的物品的信息
        /// </summary>
        SellingInfo sellingInfo;

        /// <summary>
        /// 图表的类型
        /// </summary>
        E_ChartType type;

        bool shownAsPie = false;

        List<string> names1;
        List<string> names2;

        public ChartPanel()
        {
            InitializeComponent();
            this.combo2.Hide();
            this.combo1.Hide();
            this.label2.Hide();
            this.label1.Hide();
            this.label_lowestPrice.Hide();
            this.label_priceLabel.Hide();
            this.btn_changeForm.Hide();

            Text = "图表";
        }

        public ChartPanel(SellingInfo sellingInfo, E_ChartType type) : this()
        {
            this.type = type;
            this.sellingInfo = sellingInfo;
            this.combo2.Show();
            this.label2.Show();
            this.label_lowestPrice.Show();
            this.label_priceLabel.Show();
            this.label2.Text = "时间跨度";
            combo2.Items.Add(E_Timespan.Week);
            combo2.Items.Add(E_Timespan.Month);
            combo2.Items.Add(E_Timespan.Year);
            combo2.SelectedIndex = 0;

            Text = "历史价格";
        }

        public ChartPanel(E_ChartType type) : this()
        {
            this.type = type;
            switch (type)
            {
                case E_ChartType.FavoriteCount:
                    this.btn_changeForm.Show();
                    Text = "不同商品的收藏量";
                    AddChart(0, Manager.Instance.GetFavoriteCount("所有用户"), SeriesChartType.Column, "", "商品", "收藏量", Color.Aqua);
                    break;
                case E_ChartType.FavoritesDistribution:
                    this.btn_changeForm.Show();
                    this.combo1.Show();
                    this.label1.Show();
                    this.combo2.Show();
                    this.label2.Show();
                    this.label1.Text = "商品";
                    this.label2.Text = "分布依据";
                    combo1.Items.Add("所有商品");
                    names1 = Manager.Instance.GetNames(E_RelationType.Commodity);
                    foreach (string s in names1)
                    {
                        combo1.Items.Add(s);
                    }
                    combo2.Items.Add(E_RelationType.Seller);
                    combo2.Items.Add(E_RelationType.Platform);
                    combo2.Items.Add(E_RelationType.User);

                    break;
                case E_ChartType.HistoryPriceRange:
                    this.combo1.Show();
                    this.label1.Show();
                    this.combo2.Show();
                    this.label2.Show();
                    this.label1.Text = "商品名";
                    this.label2.Text = "时间跨度";
                    names1 = Manager.Instance.GetNames(E_RelationType.Commodity);
                    foreach (string s in names1)
                    {
                        combo1.Items.Add(s);
                    }
                    combo2.Items.Add(E_Timespan.Week);
                    combo2.Items.Add(E_Timespan.Month);
                    combo2.Items.Add(E_Timespan.Year);

                    Text = "商品历史价格价差价的分析";
                    break;
                case E_ChartType.PriceDifferences:
                    this.combo1.Show();
                    this.label1.Show();
                    this.combo2.Show();
                    this.label2.Show();
                    this.label1.Text = "商品名";
                    this.label2.Text = "平台";

                    names1 = Manager.Instance.GetNames(E_RelationType.Commodity);
                    foreach (string s in names1)
                    {
                        combo1.Items.Add(s);
                    }
                    names2 = Manager.Instance.GetNames(E_RelationType.Platform);
                    foreach (string s in names2)
                    {
                        combo2.Items.Add(s);
                    }

                    Text = "商品在商家间的价格差异";
                    break;
                case E_ChartType.UserFavorites:
                    this.combo1.Show();
                    this.label1.Show();
                    this.label1.Text = "用户名";

                    names1 = Manager.Instance.GetNames(E_RelationType.User);
                    foreach (string s in names1)
                    {
                        combo1.Items.Add(s);
                    }

                    Text = "用户收藏夹";
                    break;
                case E_ChartType.PriceInclination:
                    this.btn_changeForm.Show();
                    this.combo1.Show();
                    this.label1.Show();
                    this.label1.Text = "用户名";
                    names1 = Manager.Instance.GetNames(E_RelationType.User);
                    combo1.Items.Add("所有用户");
                    foreach (string s in names1)
                    {
                        combo1.Items.Add(s);
                    }

                    Text = "用户收藏的价格倾向";
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 获取指定商品在一段时间内的历史价格
        /// </summary>
        /// <param name="timespan">时间段</param>
        /// <returns></returns>
        Dictionary<DateTime, float> GetHistoryPrices(int timespan)
        {
            Dictionary<DateTime, float> dict = Manager.Instance.GetHistoryPrices(sellingInfo, timespan);
            if (dict.Count < timespan)
            {
                return FillTheChart(dict, timespan);
            }
            return dict;
        }

        /// <summary>
        /// 填充图表
        /// </summary>
        /// <param name="dict"></param>
        /// <param name="timespan"></param>
        Dictionary<DateTime, float> FillTheChart(Dictionary<DateTime, float> dict, int timespan)
        {
            Dictionary<DateTime, float> newDict = new Dictionary<DateTime, float>();
            DateTime date = DateTime.Today.AddDays(-timespan);
            float price = Manager.Instance.GetHistoryPricesBefore(sellingInfo, timespan);
            for (int i = 1; i <= timespan; i++)
            {
                DateTime newDate = date.AddDays(i);
                if (!dict.ContainsKey(newDate))
                {
                    newDict.Add(newDate, price);
                }
                else
                {
                    price = dict[newDate];
                    newDict.Add(newDate, price);
                }
            }
            return newDict;
        }

        /// <summary>
        /// 新增一张图表
        /// </summary>
        /// <param name="index"></param>
        /// <param name="dict"></param>
        /// <param name="seriesType"></param>
        /// <param name="seriesName"></param>
        public void AddChart<K, V>(int index, Dictionary<K, V> dict, SeriesChartType seriesType, string seriesName, Color color)
        {
            mainChart.Series.Add(new Series());
            mainChart.Series[index].Name = seriesName;
            mainChart.Series[index].ChartType = seriesType;
            mainChart.Series[index].BorderWidth = 2;
            mainChart.Series[index].Color = color;
            mainChart.Series[index].IsValueShownAsLabel = true;
            foreach (KeyValuePair<K, V> item in dict)
            {
                mainChart.Series[index].Points.AddXY(item.Key, item.Value);
            }
        }

        public void AddChart<K, V>(int index, Dictionary<K, V> dict, SeriesChartType seriesType, string seriesName, string xName, string yName, Color color)
        {
            AddChart(index, dict, seriesType, seriesName, color);
            mainChart.ChartAreas[index].AxisX.Title = xName;
            mainChart.ChartAreas[index].AxisY.Title = yName;
        }

        public void AddChart<K, V>(int index, Dictionary<K, V> dict, SeriesChartType seriesType, string seriesName, string xName, string yName, double maxY, Color color)
        {
            AddChart(index, dict, seriesType, seriesName, xName, yName, color);
            mainChart.ChartAreas[index].AxisY.Maximum = maxY;
        }

        private void btn_return_Click(object sender, EventArgs e)
        {
            Close();
        }

        void SelectedIndexChanged()
        {
            mainChart.Series.Clear();
            mainChart.Legends.Clear();
            switch (type)
            {
                case E_ChartType.FavoriteCount:
                    SeriesChartType type = SeriesChartType.Column;
                    if (shownAsPie)
                    {
                        type = SeriesChartType.Pie;
                        mainChart.Legends.Add(new Legend());
                    }
                    AddChart(0, Manager.Instance.GetFavoriteCount("所有用户"), type, "", "商品", "收藏量", Color.Aqua);
                    break;
                case E_ChartType.HistoryPrices:
                    AddChart(0, GetHistoryPrices((int)combo2.SelectedItem), SeriesChartType.Line, "历史价格", "日期", "价格", Color.Red);
                    double min = 99999999;
                    foreach (DataPoint p in mainChart.Series[0].Points)
                    {
                        double value = p.YValues[0];
                        if (value < min && value != 0)
                        {
                            min = p.YValues[0];
                        }
                    }
                    label_lowestPrice.Text = min.ToString() + "元";
                    break;
                case E_ChartType.FavoritesDistribution:
                    if (combo1.SelectedItem == null || combo2.SelectedItem == null)
                        return;

                    string commodityName = combo1.SelectedItem.ToString();
                    E_RelationType t = (E_RelationType)combo2.SelectedItem;
                    string xName = "";
                    switch (t)
                    {
                        case E_RelationType.Platform:
                            Text = "收藏商品在平台间的分布";
                            xName = "平台";
                            break;
                        case E_RelationType.Seller:
                            Text = "收藏商品在商家间的分布";
                            xName = "商家";
                            break;
                        case E_RelationType.User:
                            Text = "收藏商品在用户间的分布";
                            xName = "用户名";
                            break;
                        default:
                            break;
                    }

                    Dictionary<string, int> resultInt = Manager.Instance.GetFavoritesDistribution(commodityName, (E_RelationType)combo2.SelectedItem);
                    double maxY;
                    if (resultInt.Count == 0)
                        maxY = 0;
                    else
                        maxY = resultInt.Max(k => k.Value) * 1.15;

                    type = SeriesChartType.Column;
                    if (shownAsPie)
                    {
                        type = SeriesChartType.Pie;
                        mainChart.Legends.Add(new Legend());
                    }

                    AddChart(0, resultInt, type, "", xName, "收藏量", maxY, Color.Red);
                    break;
                case E_ChartType.HistoryPriceRange:
                    if (combo1.SelectedItem == null || combo2.SelectedItem == null)
                        return;

                    commodityName = combo1.SelectedItem.ToString();
                    int timespan = (int)combo2.SelectedItem;

                    Dictionary<string, float> resultDouble = Manager.Instance.GetHistoryPriceRange(commodityName, timespan);
                    if (resultDouble.Count == 0)
                        maxY = 0;
                    else
                        maxY = resultDouble.Max(k => k.Value) * 1.15;

                    AddChart(0, resultDouble, SeriesChartType.Column, "", "商家", "价格差", maxY, Color.Blue);
                    break;
                case E_ChartType.PriceDifferences:
                    if (combo1.SelectedItem == null || combo2.SelectedItem == null)
                        return;

                    commodityName = combo1.SelectedItem.ToString();
                    string platformName = combo2.SelectedItem.ToString();

                    resultDouble = Manager.Instance.GetPriceDifferencesBetweenSellers(commodityName, platformName);
                    if (resultDouble.Count == 0)
                        maxY = 0;
                    else
                        maxY = resultDouble.Max(k => k.Value) * 1.15;

                    AddChart(0, resultDouble, SeriesChartType.Line, "", "商家", "价格", maxY, Color.IndianRed);
                    break;
                case E_ChartType.UserFavorites:
                    string userName = combo1.SelectedItem.ToString();

                    resultInt = Manager.Instance.GetFavoriteCount(userName);
                    if (resultInt.Count == 0)
                        maxY = 0;
                    else
                        maxY = resultInt.Max(k => k.Value) * 1.15;

                    AddChart(0, resultInt, SeriesChartType.Column, "", "商品", "收藏量", maxY, Color.IndianRed);
                    break;
                case E_ChartType.PriceInclination:
                    userName = combo1.SelectedItem.ToString();
                    resultInt = Manager.Instance.GetUserPriceInclination(userName);
                    if (resultInt.Count == 0)
                        maxY = 0;
                    else
                        maxY = resultInt.Max(k => k.Value) * 1.15;

                    type = SeriesChartType.Column;
                    if (shownAsPie)
                    {
                        type = SeriesChartType.Pie;
                        mainChart.Legends.Add(new Legend());
                    }

                    AddChart(0, resultInt, type, "", "价格区间", "收藏量", maxY, Color.Cyan);
                    break;
                default:
                    break;
            }
        }

        private void SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectedIndexChanged();
        }

        private void btn_changeForm_Click(object sender, EventArgs e)
        {
            shownAsPie = !shownAsPie;
            SelectedIndexChanged();
        }

        private void combo1_TextUpdate(object sender, EventArgs e)
        {
            if (names1 == null)
                return;
            //清空combobox
            this.combo1.Items.Clear();
            //遍历全部备查数据
            foreach (var item in names1)
            {
                if (item.Contains(this.combo1.Text))
                {
                    //符合，插入ListNew
                    combo1.Items.Add(item);
                }
            }
            //设置光标位置，否则光标位置始终保持在第一列，造成输入关键词的倒序排列
            this.combo1.SelectionStart = this.combo1.Text.Length;
            //保持鼠标指针原来状态，有时候鼠标指针会被下拉框覆盖，所以要进行一次设置。
            Cursor = Cursors.Default;
            //自动弹出下拉框
            this.combo1.DroppedDown = true;
        }

        private void combo2_TextUpdate(object sender, EventArgs e)
        {
            if (names2 == null)
                return;
            //清空combobox
            this.combo2.Items.Clear();
            //遍历全部备查数据
            foreach (var item in names2)
            {
                if (item.Contains(this.combo2.Text))
                {
                    //符合，插入ListNew
                    combo2.Items.Add(item);
                }
            }
            //设置光标位置，否则光标位置始终保持在第一列，造成输入关键词的倒序排列
            this.combo2.SelectionStart = this.combo2.Text.Length;
            //保持鼠标指针原来状态，有时候鼠标指针会被下拉框覆盖，所以要进行一次设置。
            Cursor = Cursors.Default;
            //自动弹出下拉框
            this.combo2.DroppedDown = true;
        }
    }
}
