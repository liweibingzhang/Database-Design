﻿namespace DD_PJ
{
    partial class UserPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_password = new System.Windows.Forms.Label();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.text_password = new System.Windows.Forms.TextBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_return = new System.Windows.Forms.Button();
            this.text_birthDate = new System.Windows.Forms.TextBox();
            this.label_description = new System.Windows.Forms.Label();
            this.text_phone = new System.Windows.Forms.TextBox();
            this.label_address = new System.Windows.Forms.Label();
            this.text_fullname = new System.Windows.Forms.TextBox();
            this.label_fullname = new System.Windows.Forms.Label();
            this.text_address = new System.Windows.Forms.TextBox();
            this.label_birthDate = new System.Windows.Forms.Label();
            this.dateTime_birthDate = new System.Windows.Forms.DateTimePicker();
            this.btn_message = new System.Windows.Forms.Button();
            this.label_notRead = new System.Windows.Forms.Label();
            this.btn_favorite = new System.Windows.Forms.Button();
            this.btn_showCommodities = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_priceDiff = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_priceRange = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("等线", 11F);
            this.label_password.Location = new System.Drawing.Point(422, 78);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(85, 19);
            this.label_password.TabIndex = 43;
            this.label_password.Text = "密　　码";
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("等线", 11F);
            this.btn_cancel.Location = new System.Drawing.Point(432, 230);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(87, 36);
            this.btn_cancel.TabIndex = 42;
            this.btn_cancel.Text = "取消";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // text_password
            // 
            this.text_password.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_password.Location = new System.Drawing.Point(521, 75);
            this.text_password.MaxLength = 20;
            this.text_password.Name = "text_password";
            this.text_password.ReadOnly = true;
            this.text_password.Size = new System.Drawing.Size(215, 26);
            this.text_password.TabIndex = 44;
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("等线", 11F);
            this.btn_save.Location = new System.Drawing.Point(278, 230);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(87, 36);
            this.btn_save.TabIndex = 38;
            this.btn_save.Text = "保存";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_edit
            // 
            this.btn_edit.Font = new System.Drawing.Font("等线", 11F);
            this.btn_edit.Location = new System.Drawing.Point(356, 230);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(87, 36);
            this.btn_edit.TabIndex = 37;
            this.btn_edit.Text = "编辑";
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 11F);
            this.btn_return.Location = new System.Drawing.Point(356, 458);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(87, 36);
            this.btn_return.TabIndex = 35;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // text_birthDate
            // 
            this.text_birthDate.Font = new System.Drawing.Font("等线", 10.8F);
            this.text_birthDate.Location = new System.Drawing.Point(521, 130);
            this.text_birthDate.MaxLength = 50;
            this.text_birthDate.Name = "text_birthDate";
            this.text_birthDate.ReadOnly = true;
            this.text_birthDate.Size = new System.Drawing.Size(215, 26);
            this.text_birthDate.TabIndex = 34;
            // 
            // label_description
            // 
            this.label_description.AutoSize = true;
            this.label_description.Font = new System.Drawing.Font("等线", 11F);
            this.label_description.Location = new System.Drawing.Point(45, 190);
            this.label_description.Name = "label_description";
            this.label_description.Size = new System.Drawing.Size(85, 19);
            this.label_description.TabIndex = 33;
            this.label_description.Text = "住　　址";
            // 
            // text_phone
            // 
            this.text_phone.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_phone.Location = new System.Drawing.Point(135, 130);
            this.text_phone.MaxLength = 20;
            this.text_phone.Name = "text_phone";
            this.text_phone.ReadOnly = true;
            this.text_phone.Size = new System.Drawing.Size(245, 26);
            this.text_phone.TabIndex = 32;
            this.text_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_phone_KeyPress);
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("等线", 11F);
            this.label_address.Location = new System.Drawing.Point(45, 133);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(85, 19);
            this.label_address.TabIndex = 31;
            this.label_address.Text = "电话号码";
            // 
            // text_fullname
            // 
            this.text_fullname.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_fullname.Location = new System.Drawing.Point(135, 75);
            this.text_fullname.MaxLength = 40;
            this.text_fullname.Name = "text_fullname";
            this.text_fullname.ReadOnly = true;
            this.text_fullname.Size = new System.Drawing.Size(245, 26);
            this.text_fullname.TabIndex = 30;
            // 
            // label_fullname
            // 
            this.label_fullname.AutoSize = true;
            this.label_fullname.Font = new System.Drawing.Font("等线", 11F);
            this.label_fullname.Location = new System.Drawing.Point(45, 78);
            this.label_fullname.Name = "label_fullname";
            this.label_fullname.Size = new System.Drawing.Size(85, 19);
            this.label_fullname.TabIndex = 29;
            this.label_fullname.Text = "全　　名";
            // 
            // text_address
            // 
            this.text_address.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_address.Location = new System.Drawing.Point(136, 187);
            this.text_address.MaxLength = 50;
            this.text_address.Name = "text_address";
            this.text_address.ReadOnly = true;
            this.text_address.Size = new System.Drawing.Size(600, 26);
            this.text_address.TabIndex = 46;
            // 
            // label_birthDate
            // 
            this.label_birthDate.AutoSize = true;
            this.label_birthDate.Font = new System.Drawing.Font("等线", 11F);
            this.label_birthDate.Location = new System.Drawing.Point(422, 133);
            this.label_birthDate.Name = "label_birthDate";
            this.label_birthDate.Size = new System.Drawing.Size(85, 19);
            this.label_birthDate.TabIndex = 45;
            this.label_birthDate.Text = "生　　日";
            // 
            // dateTime_birthDate
            // 
            this.dateTime_birthDate.Font = new System.Drawing.Font("等线", 11F);
            this.dateTime_birthDate.Location = new System.Drawing.Point(521, 130);
            this.dateTime_birthDate.Name = "dateTime_birthDate";
            this.dateTime_birthDate.Size = new System.Drawing.Size(215, 27);
            this.dateTime_birthDate.TabIndex = 47;
            // 
            // btn_message
            // 
            this.btn_message.Font = new System.Drawing.Font("等线", 11F);
            this.btn_message.Location = new System.Drawing.Point(690, 30);
            this.btn_message.Name = "btn_message";
            this.btn_message.Size = new System.Drawing.Size(79, 29);
            this.btn_message.TabIndex = 54;
            this.btn_message.Text = "消 息";
            this.btn_message.UseVisualStyleBackColor = true;
            this.btn_message.Click += new System.EventHandler(this.btn_message_Click);
            // 
            // label_notRead
            // 
            this.label_notRead.AutoSize = true;
            this.label_notRead.Font = new System.Drawing.Font("等线", 9F);
            this.label_notRead.ForeColor = System.Drawing.Color.Red;
            this.label_notRead.Location = new System.Drawing.Point(687, 12);
            this.label_notRead.Name = "label_notRead";
            this.label_notRead.Size = new System.Drawing.Size(82, 15);
            this.label_notRead.TabIndex = 55;
            this.label_notRead.Text = "有未读消息";
            // 
            // btn_favorite
            // 
            this.btn_favorite.Font = new System.Drawing.Font("等线", 11F);
            this.btn_favorite.Location = new System.Drawing.Point(253, 291);
            this.btn_favorite.Name = "btn_favorite";
            this.btn_favorite.Size = new System.Drawing.Size(112, 33);
            this.btn_favorite.TabIndex = 56;
            this.btn_favorite.Text = "我的收藏";
            this.btn_favorite.UseVisualStyleBackColor = true;
            this.btn_favorite.Click += new System.EventHandler(this.btn_favorites_Click);
            // 
            // btn_showCommodities
            // 
            this.btn_showCommodities.Font = new System.Drawing.Font("等线", 11F);
            this.btn_showCommodities.Location = new System.Drawing.Point(432, 291);
            this.btn_showCommodities.Name = "btn_showCommodities";
            this.btn_showCommodities.Size = new System.Drawing.Size(112, 33);
            this.btn_showCommodities.TabIndex = 57;
            this.btn_showCommodities.Text = "所有商品";
            this.btn_showCommodities.UseVisualStyleBackColor = true;
            this.btn_showCommodities.Click += new System.EventHandler(this.btn_showCommodities_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("等线", 11F);
            this.btn_delete.Location = new System.Drawing.Point(339, 289);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(125, 36);
            this.btn_delete.TabIndex = 58;
            this.btn_delete.Text = "删除该用户";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_priceDiff
            // 
            this.btn_priceDiff.Font = new System.Drawing.Font("等线", 11F);
            this.btn_priceDiff.Location = new System.Drawing.Point(100, 389);
            this.btn_priceDiff.Name = "btn_priceDiff";
            this.btn_priceDiff.Size = new System.Drawing.Size(280, 36);
            this.btn_priceDiff.TabIndex = 86;
            this.btn_priceDiff.Text = "商品在商家间的价格差异";
            this.btn_priceDiff.UseVisualStyleBackColor = true;
            this.btn_priceDiff.Click += new System.EventHandler(this.btn_priceDiff_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("等线", 11F);
            this.label1.Location = new System.Drawing.Point(45, 345);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 87;
            this.label1.Text = "进阶查询";
            // 
            // btn_priceRange
            // 
            this.btn_priceRange.Font = new System.Drawing.Font("等线", 11F);
            this.btn_priceRange.Location = new System.Drawing.Point(426, 389);
            this.btn_priceRange.Name = "btn_priceRange";
            this.btn_priceRange.Size = new System.Drawing.Size(280, 36);
            this.btn_priceRange.TabIndex = 88;
            this.btn_priceRange.Text = "商品历史价格极差";
            this.btn_priceRange.UseVisualStyleBackColor = true;
            this.btn_priceRange.Click += new System.EventHandler(this.btn_priceRange_Click);
            // 
            // UserPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 530);
            this.Controls.Add(this.btn_priceRange);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_priceDiff);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_showCommodities);
            this.Controls.Add(this.btn_favorite);
            this.Controls.Add(this.label_notRead);
            this.Controls.Add(this.btn_message);
            this.Controls.Add(this.dateTime_birthDate);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.label_birthDate);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.text_password);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.text_birthDate);
            this.Controls.Add(this.label_description);
            this.Controls.Add(this.text_phone);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.text_fullname);
            this.Controls.Add(this.label_fullname);
            this.Name = "UserPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserPanel";
            this.Activated += new System.EventHandler(this.UserPanel_Activated);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.UserPanel_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.TextBox text_password;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.TextBox text_birthDate;
        private System.Windows.Forms.Label label_description;
        private System.Windows.Forms.TextBox text_phone;
        private System.Windows.Forms.Label label_address;
        private System.Windows.Forms.TextBox text_fullname;
        private System.Windows.Forms.Label label_fullname;
        private System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.Label label_birthDate;
        private System.Windows.Forms.DateTimePicker dateTime_birthDate;
        private System.Windows.Forms.Button btn_message;
        private System.Windows.Forms.Label label_notRead;
        private System.Windows.Forms.Button btn_favorite;
        private System.Windows.Forms.Button btn_showCommodities;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_priceDiff;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_priceRange;
    }
}