﻿namespace DD_PJ
{
    partial class SellingPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.text_description = new System.Windows.Forms.TextBox();
            this.label_description = new System.Windows.Forms.Label();
            this.text_address = new System.Windows.Forms.TextBox();
            this.label_address = new System.Windows.Forms.Label();
            this.text_commodityName = new System.Windows.Forms.TextBox();
            this.label_name = new System.Windows.Forms.Label();
            this.text_platformName = new System.Windows.Forms.TextBox();
            this.label_platform = new System.Windows.Forms.Label();
            this.text_life = new System.Windows.Forms.TextBox();
            this.label_life = new System.Windows.Forms.Label();
            this.text_produceDate = new System.Windows.Forms.TextBox();
            this.text_price = new System.Windows.Forms.TextBox();
            this.label_price = new System.Windows.Forms.Label();
            this.label_date = new System.Windows.Forms.Label();
            this.text_catagory = new System.Windows.Forms.TextBox();
            this.label_catagory = new System.Windows.Forms.Label();
            this.btn_return = new System.Windows.Forms.Button();
            this.btn_showHistory = new System.Windows.Forms.Button();
            this.btn_collect = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.text_sellerName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label_point = new System.Windows.Forms.Label();
            this.text_priceFloorDec = new System.Windows.Forms.TextBox();
            this.label_yuan = new System.Windows.Forms.Label();
            this.label_priceFloor = new System.Windows.Forms.Label();
            this.text_priceFloorInt = new System.Windows.Forms.TextBox();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // text_description
            // 
            this.text_description.Font = new System.Drawing.Font("等线", 10.8F);
            this.text_description.Location = new System.Drawing.Point(140, 255);
            this.text_description.MaxLength = 100;
            this.text_description.Multiline = true;
            this.text_description.Name = "text_description";
            this.text_description.ReadOnly = true;
            this.text_description.Size = new System.Drawing.Size(596, 78);
            this.text_description.TabIndex = 21;
            // 
            // label_description
            // 
            this.label_description.AutoSize = true;
            this.label_description.Font = new System.Drawing.Font("等线", 11F);
            this.label_description.Location = new System.Drawing.Point(40, 258);
            this.label_description.Name = "label_description";
            this.label_description.Size = new System.Drawing.Size(85, 19);
            this.label_description.TabIndex = 20;
            this.label_description.Text = "详细描述";
            // 
            // text_address
            // 
            this.text_address.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_address.Location = new System.Drawing.Point(140, 204);
            this.text_address.MaxLength = 50;
            this.text_address.Name = "text_address";
            this.text_address.ReadOnly = true;
            this.text_address.Size = new System.Drawing.Size(596, 26);
            this.text_address.TabIndex = 19;
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("等线", 11F);
            this.label_address.Location = new System.Drawing.Point(40, 207);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(85, 19);
            this.label_address.TabIndex = 18;
            this.label_address.Text = "生产地址";
            // 
            // text_commodityName
            // 
            this.text_commodityName.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_commodityName.Location = new System.Drawing.Point(140, 40);
            this.text_commodityName.MaxLength = 20;
            this.text_commodityName.Name = "text_commodityName";
            this.text_commodityName.ReadOnly = true;
            this.text_commodityName.Size = new System.Drawing.Size(220, 26);
            this.text_commodityName.TabIndex = 17;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("等线", 11F);
            this.label_name.Location = new System.Drawing.Point(40, 43);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(85, 19);
            this.label_name.TabIndex = 14;
            this.label_name.Text = "名　　称";
            // 
            // text_platformName
            // 
            this.text_platformName.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_platformName.Location = new System.Drawing.Point(496, 95);
            this.text_platformName.MaxLength = 20;
            this.text_platformName.Name = "text_platformName";
            this.text_platformName.ReadOnly = true;
            this.text_platformName.Size = new System.Drawing.Size(240, 26);
            this.text_platformName.TabIndex = 23;
            // 
            // label_platform
            // 
            this.label_platform.AutoSize = true;
            this.label_platform.Font = new System.Drawing.Font("等线", 11F);
            this.label_platform.Location = new System.Drawing.Point(396, 98);
            this.label_platform.Name = "label_platform";
            this.label_platform.Size = new System.Drawing.Size(85, 19);
            this.label_platform.TabIndex = 22;
            this.label_platform.Text = "销售平台";
            // 
            // text_life
            // 
            this.text_life.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_life.Location = new System.Drawing.Point(657, 150);
            this.text_life.MaxLength = 40;
            this.text_life.Name = "text_life";
            this.text_life.ReadOnly = true;
            this.text_life.Size = new System.Drawing.Size(79, 26);
            this.text_life.TabIndex = 29;
            // 
            // label_life
            // 
            this.label_life.AutoSize = true;
            this.label_life.Font = new System.Drawing.Font("等线", 11F);
            this.label_life.Location = new System.Drawing.Point(575, 153);
            this.label_life.Name = "label_life";
            this.label_life.Size = new System.Drawing.Size(76, 19);
            this.label_life.TabIndex = 28;
            this.label_life.Text = "保 质 期";
            // 
            // text_produceDate
            // 
            this.text_produceDate.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_produceDate.Location = new System.Drawing.Point(392, 150);
            this.text_produceDate.MaxLength = 40;
            this.text_produceDate.Name = "text_produceDate";
            this.text_produceDate.ReadOnly = true;
            this.text_produceDate.Size = new System.Drawing.Size(177, 26);
            this.text_produceDate.TabIndex = 27;
            // 
            // text_price
            // 
            this.text_price.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_price.Location = new System.Drawing.Point(140, 150);
            this.text_price.Name = "text_price";
            this.text_price.ReadOnly = true;
            this.text_price.Size = new System.Drawing.Size(140, 26);
            this.text_price.TabIndex = 26;
            // 
            // label_price
            // 
            this.label_price.AutoSize = true;
            this.label_price.Font = new System.Drawing.Font("等线", 11F);
            this.label_price.Location = new System.Drawing.Point(40, 153);
            this.label_price.Name = "label_price";
            this.label_price.Size = new System.Drawing.Size(85, 19);
            this.label_price.TabIndex = 25;
            this.label_price.Text = "售　　价";
            // 
            // label_date
            // 
            this.label_date.AutoSize = true;
            this.label_date.Font = new System.Drawing.Font("等线", 11F);
            this.label_date.Location = new System.Drawing.Point(301, 153);
            this.label_date.Name = "label_date";
            this.label_date.Size = new System.Drawing.Size(85, 19);
            this.label_date.TabIndex = 24;
            this.label_date.Text = "生产日期";
            // 
            // text_catagory
            // 
            this.text_catagory.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_catagory.Location = new System.Drawing.Point(496, 40);
            this.text_catagory.MaxLength = 20;
            this.text_catagory.Name = "text_catagory";
            this.text_catagory.ReadOnly = true;
            this.text_catagory.Size = new System.Drawing.Size(240, 26);
            this.text_catagory.TabIndex = 31;
            // 
            // label_catagory
            // 
            this.label_catagory.AutoSize = true;
            this.label_catagory.Font = new System.Drawing.Font("等线", 11F);
            this.label_catagory.Location = new System.Drawing.Point(396, 43);
            this.label_catagory.Name = "label_catagory";
            this.label_catagory.Size = new System.Drawing.Size(85, 19);
            this.label_catagory.TabIndex = 30;
            this.label_catagory.Text = "类　　别";
            // 
            // btn_return
            // 
            this.btn_return.Font = new System.Drawing.Font("等线", 11F);
            this.btn_return.Location = new System.Drawing.Point(357, 445);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(87, 36);
            this.btn_return.TabIndex = 32;
            this.btn_return.Text = "返 回";
            this.btn_return.UseVisualStyleBackColor = true;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // btn_showHistory
            // 
            this.btn_showHistory.Font = new System.Drawing.Font("等线", 11F);
            this.btn_showHistory.Location = new System.Drawing.Point(481, 350);
            this.btn_showHistory.Name = "btn_showHistory";
            this.btn_showHistory.Size = new System.Drawing.Size(110, 36);
            this.btn_showHistory.TabIndex = 34;
            this.btn_showHistory.Text = "历史价格";
            this.btn_showHistory.UseVisualStyleBackColor = true;
            this.btn_showHistory.Click += new System.EventHandler(this.btn_showHistory_Click);
            // 
            // btn_collect
            // 
            this.btn_collect.Font = new System.Drawing.Font("等线", 11F);
            this.btn_collect.Location = new System.Drawing.Point(346, 350);
            this.btn_collect.Name = "btn_collect";
            this.btn_collect.Size = new System.Drawing.Size(110, 36);
            this.btn_collect.TabIndex = 35;
            this.btn_collect.Text = "收　藏";
            this.btn_collect.UseVisualStyleBackColor = true;
            this.btn_collect.Click += new System.EventHandler(this.btn_collect_Click);
            // 
            // btn_remove
            // 
            this.btn_remove.Font = new System.Drawing.Font("等线", 11F);
            this.btn_remove.Location = new System.Drawing.Point(346, 350);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(110, 36);
            this.btn_remove.TabIndex = 33;
            this.btn_remove.Text = "下架商品";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // text_sellerName
            // 
            this.text_sellerName.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_sellerName.Location = new System.Drawing.Point(140, 95);
            this.text_sellerName.MaxLength = 40;
            this.text_sellerName.Name = "text_sellerName";
            this.text_sellerName.ReadOnly = true;
            this.text_sellerName.Size = new System.Drawing.Size(220, 26);
            this.text_sellerName.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("等线", 11F);
            this.label1.Location = new System.Drawing.Point(40, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 36;
            this.label1.Text = "商　　家";
            // 
            // label_point
            // 
            this.label_point.AutoSize = true;
            this.label_point.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_point.Location = new System.Drawing.Point(230, 359);
            this.label_point.Name = "label_point";
            this.label_point.Size = new System.Drawing.Size(13, 19);
            this.label_point.TabIndex = 46;
            this.label_point.Text = ".";
            // 
            // text_priceFloorDec
            // 
            this.text_priceFloorDec.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_priceFloorDec.Location = new System.Drawing.Point(249, 352);
            this.text_priceFloorDec.MaxLength = 2;
            this.text_priceFloorDec.Name = "text_priceFloorDec";
            this.text_priceFloorDec.Size = new System.Drawing.Size(41, 26);
            this.text_priceFloorDec.TabIndex = 45;
            this.text_priceFloorDec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_priceFloorDec_KeyPress);
            // 
            // label_yuan
            // 
            this.label_yuan.AutoSize = true;
            this.label_yuan.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_yuan.Location = new System.Drawing.Point(290, 359);
            this.label_yuan.Name = "label_yuan";
            this.label_yuan.Size = new System.Drawing.Size(27, 19);
            this.label_yuan.TabIndex = 44;
            this.label_yuan.Text = "元";
            // 
            // label_priceFloor
            // 
            this.label_priceFloor.AutoSize = true;
            this.label_priceFloor.Font = new System.Drawing.Font("等线", 11F);
            this.label_priceFloor.Location = new System.Drawing.Point(40, 359);
            this.label_priceFloor.Name = "label_priceFloor";
            this.label_priceFloor.Size = new System.Drawing.Size(85, 19);
            this.label_priceFloor.TabIndex = 43;
            this.label_priceFloor.Text = "价格下限";
            // 
            // text_priceFloorInt
            // 
            this.text_priceFloorInt.Font = new System.Drawing.Font("等线", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.text_priceFloorInt.Location = new System.Drawing.Point(140, 352);
            this.text_priceFloorInt.MaxLength = 5;
            this.text_priceFloorInt.Name = "text_priceFloorInt";
            this.text_priceFloorInt.Size = new System.Drawing.Size(88, 26);
            this.text_priceFloorInt.TabIndex = 42;
            this.text_priceFloorInt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_priceFloorInt_KeyPress);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("等线", 11F);
            this.btn_cancel.Location = new System.Drawing.Point(346, 350);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(110, 36);
            this.btn_cancel.TabIndex = 47;
            this.btn_cancel.Text = "取消收藏";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // SellingPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 493);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.label_point);
            this.Controls.Add(this.text_priceFloorDec);
            this.Controls.Add(this.label_yuan);
            this.Controls.Add(this.label_priceFloor);
            this.Controls.Add(this.text_priceFloorInt);
            this.Controls.Add(this.text_sellerName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_collect);
            this.Controls.Add(this.btn_showHistory);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.text_catagory);
            this.Controls.Add(this.label_catagory);
            this.Controls.Add(this.text_life);
            this.Controls.Add(this.label_life);
            this.Controls.Add(this.text_produceDate);
            this.Controls.Add(this.text_price);
            this.Controls.Add(this.label_price);
            this.Controls.Add(this.label_date);
            this.Controls.Add(this.text_platformName);
            this.Controls.Add(this.label_platform);
            this.Controls.Add(this.text_description);
            this.Controls.Add(this.label_description);
            this.Controls.Add(this.text_address);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.text_commodityName);
            this.Controls.Add(this.label_name);
            this.Name = "SellingPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CommodityPanel_Seller";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox text_description;
        private System.Windows.Forms.Label label_description;
        private System.Windows.Forms.TextBox text_address;
        private System.Windows.Forms.Label label_address;
        private System.Windows.Forms.TextBox text_commodityName;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.TextBox text_platformName;
        private System.Windows.Forms.Label label_platform;
        private System.Windows.Forms.TextBox text_life;
        private System.Windows.Forms.Label label_life;
        private System.Windows.Forms.TextBox text_produceDate;
        private System.Windows.Forms.TextBox text_price;
        private System.Windows.Forms.Label label_price;
        private System.Windows.Forms.Label label_date;
        private System.Windows.Forms.TextBox text_catagory;
        private System.Windows.Forms.Label label_catagory;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Button btn_showHistory;
        private System.Windows.Forms.Button btn_collect;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.TextBox text_sellerName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_point;
        private System.Windows.Forms.TextBox text_priceFloorDec;
        private System.Windows.Forms.Label label_yuan;
        private System.Windows.Forms.Label label_priceFloor;
        private System.Windows.Forms.TextBox text_priceFloorInt;
        private System.Windows.Forms.Button btn_cancel;
    }
}