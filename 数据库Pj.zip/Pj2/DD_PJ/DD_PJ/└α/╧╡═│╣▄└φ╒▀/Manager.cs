﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;
using MySqlX.XDevAPI.Relational;
using pj_DBD;

namespace DD_PJ
{
    /// <summary>
    /// 系统管理者
    /// </summary>
    public class Manager
    {
        private static Manager instance = new Manager();
        public static Manager Instance => instance;

        /// <summary>
        /// 和数据库的连接
        /// </summary>
        MySqlConnection conn;

        /// <summary>
        /// 数据库操作命令
        /// </summary>
        MySqlCommand cmd;

        private Manager()
        {
            //连入数据库
            conn = new MySqlConnection("server=localhost;username=root;password=1234;database=PCS;");
            conn.Open();
        }
        
        #region 添加记录的方法

        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="userType">用户类型</param>
        /// <param name="name">用户名/商家名</param>
        /// <param name="password">密码</param>
        public bool Register(string name, string password, E_RelationType userType)
        {
            string cmdStr = "";
            switch (userType)
            {
                case E_RelationType.User:
                    cmdStr = string.Format("INSERT INTO `user` VALUES(null, '{0}', '{1}', null, null, null, null)", name, password);
                    break;
                case E_RelationType.Seller:
                    cmdStr = string.Format("INSERT INTO `seller` VALUES(null, '{0}', '{1}', null, null, null, null)", name, password);
                    break;
                default:
                    break;
            }
            cmd = new MySqlCommand(cmdStr, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 新增一件可供售卖的商品
        /// </summary>
        /// <param name="name">商品名</param>
        /// <param name="category">商品种类</param>
        /// <returns></returns>
        public bool AddCommodity(string name, string category)
        {
            string cmdStr = string.Format("INSERT INTO `commodity` VALUES(null, '{0}', '{1}')", name, category);
            cmd = new MySqlCommand(cmdStr, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 添加一个平台
        /// </summary>
        /// <param name="name">平台名</param>
        /// <returns></returns>
        public bool AddPlatform(string name)
        {
            string cmdStr = string.Format("INSERT INTO `platform` VALUES(null, '{0}')", name);
            cmd = new MySqlCommand(cmdStr, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 发布商品
        /// </summary>
        /// <param name="sellingInfo">要发布的商品信息</param>
        public void Publish(SellingInfo sellingInfo)
        {
            try
            {
                cmd = new MySqlCommand();
                cmd.Connection = conn;
                // 构造插入语句
                cmd.CommandText =
                    "INSERT INTO selling (commodity_id, seller_id, platform_id, produce_date, shelf_life, produce_address, price, description) " +
                    "VALUES (@commodity_id, @seller_id, @platform_id, @produce_date, @shelf_life, @produce_address, @price, @description)";

                // 添加参数
                cmd.Parameters.AddWithValue("@commodity_id", sellingInfo.commodity_id);
                cmd.Parameters.AddWithValue("@seller_id", sellingInfo.seller_id);
                cmd.Parameters.AddWithValue("@platform_id", sellingInfo.platform_id);
                cmd.Parameters.AddWithValue("@produce_date", DateTime.Parse(sellingInfo.produce_date));
                cmd.Parameters.AddWithValue("@shelf_life", int.Parse(sellingInfo.shelf_life));
                cmd.Parameters.AddWithValue("@produce_address", sellingInfo.produce_address);
                cmd.Parameters.AddWithValue("@price", decimal.Parse(sellingInfo.price));
                cmd.Parameters.AddWithValue("@description", sellingInfo.description);
                // 执行插入操作
                cmd.ExecuteNonQuery();

                MessageBox.Show("Publish successful!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        /// <summary>
        /// 用户收藏商品的方法
        /// </summary>
        /// <param name="userID">用户id</param>
        /// <param name="favorite">要收藏的商品的信息</param>
        public bool AddToFavorites(string userID, SellingInfo favorite)
        {
            string cmdStr = string.Format("INSERT INTO `favorite` " +
                                          "VALUES({0}, {1}, {2}, {3}, {4})",
                                          userID, favorite.commodity_id, favorite.seller_id, favorite.platform_id, favorite.priceFloor);
            cmd = new MySqlCommand(cmdStr, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        #endregion

        #region 获取记录的方法

        /// <summary>
        /// 获取某个关系模式中所有记录的名称
        /// </summary>
        /// <param name="type">关系模式</param>
        /// <returns></returns>
        public List<string> GetNames(E_RelationType type)
        {
            List<string> list = new List<string>();

            string relation = "";
            switch (type)
            {
                case E_RelationType.User:
                    relation = "user";
                    break;
                case E_RelationType.Seller:
                    relation = "seller";
                    break;
                case E_RelationType.Administrator:
                    relation = "administrator";
                    break;
                case E_RelationType.Commodity:
                    relation = "commodity";
                    break;
                case E_RelationType.Platform:
                    relation = "platform";
                    break;
                default:
                    break;
            }

            string cmdStr = string.Format("SELECT `{0}_name` FROM `{1}`", relation, relation);
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    list.Add(reader.GetValue(0).ToString());
                }
            }
            return list;
        }

        /// <summary>
        /// 获取注册表
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, string> GetRegistry(E_RelationType type)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();

            string relation = "";
            switch (type)
            {
                case E_RelationType.User:
                    relation = "user";
                    break;
                case E_RelationType.Seller:
                    relation = "seller";
                    break;
                case E_RelationType.Administrator:
                    relation = "administrator";
                    break;
                default:
                    break;
            }

            string cmdStr = string.Format("SELECT `{0}_name`, `password` FROM `{1}`", relation, relation);
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string name = reader.GetValue(0).ToString();
                    string pwd = reader.GetValue(1).ToString();
                    dic.Add(name, pwd);
                }
            }
            return dic;
        }

        /// <summary>
        /// 得到一条记录
        /// </summary>
        /// <param name="index">索引</param>
        /// <param name="type">关系模式</param>
        /// <param name="selectBy">按什么搜索(名称/ID)</param>
        /// <returns></returns>
        public object GetRecord(string index, E_RelationType type, string selectBy)
        {
            string cmdStr = "";
            switch (type)
            {
                case E_RelationType.User:
                    cmdStr = "SELECT * FROM `user` WHERE `user_name` = '" + index + "'";
                    if (selectBy == "id" || selectBy == "ID" || selectBy == "Id")
                        cmdStr = "SELECT * FROM `user` WHERE `ID` = " + index;
                    cmd = new MySqlCommand(cmdStr, conn);
                    UserInfo userInfo = null;
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            userInfo = UserInfo.ToUserInfo(reader);
                        }
                    }
                    return userInfo;
                case E_RelationType.Seller:
                    cmdStr = "SELECT * FROM `seller` WHERE `seller_name` = '" + index + "'";
                    if (selectBy == "id" || selectBy == "ID" || selectBy == "Id")
                        cmdStr = "SELECT * FROM `seller` WHERE `ID` = " + index;
                    cmd = new MySqlCommand(cmdStr, conn);
                    SellerInfo sellerInfo = null;
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            sellerInfo = SellerInfo.ToSellerInfo(reader);
                        }
                    }
                    return sellerInfo;
                case E_RelationType.Administrator:
                    return "";
                case E_RelationType.Commodity:
                    cmdStr = "SELECT * FROM `commodity` WHERE `commodity_name` = '" + index + "'";
                    if (selectBy == "id" || selectBy == "ID" || selectBy == "Id")
                        cmdStr = "SELECT * FROM `commodity` WHERE `ID` = " + index;
                    cmd = new MySqlCommand(cmdStr, conn);
                    CommodityInfo commodityInfo = null;
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            commodityInfo = CommodityInfo.ToCommodityInfo(reader);
                        }
                    }
                    return commodityInfo;
                case E_RelationType.Platform:
                    cmdStr = "SELECT * FROM `platform` WHERE `platform_name` = '" + index + "'";
                    if (selectBy == "id" || selectBy == "ID" || selectBy == "Id")
                        cmdStr = "SELECT * FROM `platform` WHERE `ID` = " + index;
                    cmd = new MySqlCommand(cmdStr, conn);
                    string platformID = null;
                    string platformName = null;
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            platformID = reader.GetValue(0).ToString();
                            platformName = reader.GetValue(1).ToString();
                        }
                    }
                    return (platformID, platformName);
                default:
                    break;
            }
            return null;
        }

        /// <summary>
        /// 获取指定商家在售商品信息
        /// </summary>
        /// <param name="sellerID">商家ID</param>
        /// <returns></returns>
        public List<SellingInfo> GetSellingInfo(string sellerID)
        {
            List<SellingInfo> list = new List<SellingInfo>();

            string cmdStr = "SELECT `commodity_id`, `commodity_name`, `category`, " +
                            "`seller_id`, `seller_name`, `platform_id`, `platform_name`, `produce_date`, " +
                            "`shelf_life`, `produce_address`, `price`, `selling`.description " +
                            "FROM `selling` JOIN `commodity` ON `selling`.commodity_id = `commodity`.ID " +
                            "JOIN `seller` ON `selling`.seller_id = `seller`.ID " +
                            "JOIN `platform` ON `selling`.platform_id = `platform`.ID " +
                            "WHERE `seller_id` = " + sellerID;
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    list.Add(SellingInfo.ToSellingInfo(reader));
                }
            }
            return list;
        }

        /// <summary>
        /// 获取所有在售商品信息
        /// </summary>
        /// <returns></returns>
        public List<SellingInfo> GetSellingInfo()
        {
            List<SellingInfo> list = new List<SellingInfo>();

            string cmdStr = "SELECT `commodity_id`, `commodity_name`, `category`, " +
                            "`seller_id`, `seller_name`, `platform_id`, `platform_name`, `produce_date`, " +
                            "`shelf_life`, `produce_address`, `price`, `selling`.description " +
                            "FROM `selling` JOIN `commodity` ON `selling`.commodity_id = `commodity`.ID " +
                            "JOIN `seller` ON `selling`.seller_id = `seller`.ID " +
                            "JOIN `platform` ON `selling`.platform_id = `platform`.ID";
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    list.Add(SellingInfo.ToSellingInfo(reader));
                }
            }
            return list;
        }

        /// <summary>
        /// 加载所有商品的信息
        /// </summary>
        /// <returns></returns>
        public List<CommodityInfo> GetCommoditiesInfo()
        {
            List<CommodityInfo> list = new List<CommodityInfo>();

            string cmdStr = "SELECT * FROM `commodity`";
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    CommodityInfo info = CommodityInfo.ToCommodityInfo(reader);
                    list.Add(info);
                }
            }
            return list;
        }

        /// <summary>
        /// 加载所有商家的信息
        /// </summary>
        /// <returns></returns>
        public List<SellerInfo> GetSellersInfo()
        {
            List<SellerInfo> list = new List<SellerInfo>();

            string cmdStr = "SELECT * FROM `seller`";
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    SellerInfo info = SellerInfo.ToSellerInfo(reader);
                    list.Add(info);
                }
            }
            return list;
        }

        /// <summary>
        /// 加载所有平台的信息
        /// </summary>
        /// <returns></returns>
        public List<(string id, string name)> GetPlatformsInfo()
        {
            List<(string id, string name)> list = new List<(string id, string name)>();

            string cmdStr = "SELECT * FROM `platform`";
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string id = reader.GetValue(0).ToString();
                    string name = reader.GetValue(1).ToString();
                    list.Add((id, name));
                }
            }
            return list;
        }

        /// <summary>
        /// 加载所有用户的信息
        /// </summary>
        /// <returns></returns>
        public List<UserInfo> GetUsersInfo()
        {
            List<UserInfo> list = new List<UserInfo>();

            string cmdStr = "SELECT * FROM `user`";
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    UserInfo info = UserInfo.ToUserInfo(reader);
                    list.Add(info);
                }
            }
            return list;
        }

        /// <summary>
        /// 将在售商品中用户收藏的商品添加到收藏夹
        /// </summary>
        /// <param name="userID">用户id</param>
        /// <param name="favorites">收藏夹</param>
        /// <param name="sellingInfoList">在售商品信息</param>
        public void GetUserFavorites(string userID, List<SellingInfo> favorites, List<SellingInfo> sellingInfoList)
        {
            string cmdStr = "SELECT `commodity_id`, `seller_id`, `platform_id`, `price_floor` FROM `favorite` WHERE `user_id` = " + userID;
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string commodity_id = reader.GetValue(0).ToString();
                    string seller_id = reader.GetValue(1).ToString();
                    string platform_id = reader.GetValue(2).ToString();
                    string price_floor = reader.GetValue(3).ToString();
                    foreach (SellingInfo info in sellingInfoList)
                    {
                        if (info.commodity_id == commodity_id && info.seller_id == seller_id && info.platform_id == platform_id)
                        {
                            info.priceFloor = price_floor;
                            info.isFavorite = true;
                            favorites.Add(info);
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 获取一件商品的历史价格
        /// </summary>
        /// <param name="info"></param>
        /// <param name="timespan"></param>
        /// <returns></returns>
        public Dictionary<DateTime, float> GetHistoryPrices(SellingInfo info, int timespan)
        {
            Dictionary<DateTime, float> dict = new Dictionary<DateTime, float>();
            string cmdStr = string.Format("SELECT `price`, `date` FROM `history_price` " +
                                          "WHERE `commodity_id` = {0} and `seller_id` = {1} and `platform_id` = {2} and DATE_SUB(CURDATE(), INTERVAL {3} DAY) <= date",
                                          info.commodity_id, info.seller_id, info.platform_id, timespan);
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string price = reader.GetValue(0).ToString();
                    string date = reader.GetValue(1).ToString();
                    if (price == "")
                        price = "0";
                    dict.Add(DateTime.Parse(date), float.Parse(price));
                }
            }
            return dict;
        }

        /// <summary>
        /// 获取某时间段之前该商品最近的价格
        /// </summary>
        /// <param name="info"></param>
        /// <param name="timespan"></param>
        /// <returns></returns>
        public float GetHistoryPricesBefore(SellingInfo info, int timespan)
        {
            string price = "";
            string cmdStr = string.Format("SELECT `price`, `date` FROM `history_price` " +
                                          "WHERE `commodity_id` = {0} and `seller_id` = {1} and `platform_id` = {2} and DATE_SUB(CURDATE(), INTERVAL {3} DAY) > date " +
                                          "ORDER BY `date` DESC LIMIT 1",
                                          info.commodity_id, info.seller_id, info.platform_id, timespan);
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    price = reader.GetValue(0).ToString();
                }
            }
            if (price == "")
                price = "0";
            return float.Parse(price);
        }

        /// <summary>
        /// 获取一名用户的消息列表
        /// </summary>
        /// <param name="userID">用户id</param>
        /// <returns></returns>
        public List<UserMessage> GetUserMessages(string userID)
        {
            string cmdStr = string.Format("SELECT * FROM `message` WHERE `user_id` = {0}", userID);
            List<UserMessage> messages = new List<UserMessage>();
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    messages.Add(UserMessage.ToMessage(reader));
                }
            }
            return messages;
        }
        #endregion

        #region 更新记录的方法

        /// <summary>
        /// 更新在售商品信息
        /// </summary>
        /// <param name="sellingInfo">新的在售商品信息</param>
        public void UpdateSellingInfo(SellingInfo sellingInfo)
        {
            try
            {
                cmd = new MySqlCommand();
                cmd.Connection = conn;
                // 构造更新语句
                cmd.CommandText = "UPDATE selling " +
                                      "SET produce_date = @produce_date, " +
                                      "    shelf_life = @shelf_life, " +
                                      "    produce_address = @produce_address, " +
                                      "    price = @price, " +
                                      "    description = @description " +
                                      "WHERE commodity_id = @commodity_id AND seller_id = @seller_id AND platform_id = @platform_id";

                // 添加参数
                cmd.Parameters.AddWithValue("@produce_date", DateTime.Parse(sellingInfo.produce_date));
                cmd.Parameters.AddWithValue("@shelf_life", int.Parse(sellingInfo.shelf_life));
                cmd.Parameters.AddWithValue("@produce_address", sellingInfo.produce_address);
                cmd.Parameters.AddWithValue("@price", decimal.Parse(sellingInfo.price));
                cmd.Parameters.AddWithValue("@description", sellingInfo.description);
                cmd.Parameters.AddWithValue("@commodity_id", sellingInfo.commodity_id);
                cmd.Parameters.AddWithValue("@seller_id", sellingInfo.seller_id);
                cmd.Parameters.AddWithValue("@platform_id", sellingInfo.platform_id);

                // 执行更新操作
                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Update successful!");
                }
                else
                {
                    MessageBox.Show("No rows updated. SellingInfo not found in the database.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        /// <summary>
        /// 更新商家信息
        /// </summary>
        /// <param name="sellerInfo">商家信息</param>
        public void UpdateSellerInfo(SellerInfo sellerInfo)
        {
            string cmdStr = string.Format("UPDATE `seller` " +
                                          "SET `fullname` = '{0}', `password` = '{1}', `address` = '{2}', `description` = '{3}', `phone_number` =  '{4}' " +
                                          "WHERE `ID` = {5}",
                                          sellerInfo.fullname, sellerInfo.password, sellerInfo.address, sellerInfo.description, sellerInfo.phone_number, sellerInfo.ID);
            cmd = new MySqlCommand(cmdStr, conn);
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// 更新用户信息
        /// </summary>
        /// <param name="userInfo">用户信息</param>
        public void UpdateUserInfo(UserInfo userInfo)
        {
            string cmdStr = string.Format("UPDATE `user` " +
                                          "SET `fullname` = '{0}', `password` = '{1}', `phone_number` = '{2}', `home_address` = '{3}', `birth_date` = '{4}' " +
                                          "WHERE `ID` = {5}",
                                          userInfo.fullname, userInfo.password, userInfo.phone_number, userInfo.home_address, userInfo.birth_date, userInfo.ID);
            cmd = new MySqlCommand(cmdStr, conn);
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// 将消息设为已读
        /// </summary>
        /// <param name="messageID">消息id</param>
        public void SetMessageRead(string messageID)
        {
            string cmdStr = string.Format("UPDATE `message` SET `state` = '已读' WHERE `ID` = {0}", messageID);
            cmd = new MySqlCommand(cmdStr, conn);
            cmd.ExecuteNonQuery();
        }
        #endregion

        #region 删除记录的方法

        /// <summary>
        /// 在数据库删除一条记录
        /// </summary>
        /// <param name="index">索引</param>
        /// <param name="type">关系模式</param>
        /// <param name="deleteBy">按什么删除</param>
        public bool DeleteRecord(string index, E_RelationType type, string deleteBy)
        {
            string cmdStr = "";
            switch (type)
            {
                case E_RelationType.User:
                    cmdStr = "DELETE FROM `user` WHERE `user_name` = '" + index + "'";
                    if (deleteBy == "id" || deleteBy == "ID" || deleteBy == "Id")
                        cmdStr = "DELETE FROM `user` WHERE `ID` = " + index;
                    break;
                case E_RelationType.Seller:
                    cmdStr = "DELETE FROM `seller` WHERE `seller_name` = '" + index + "'";
                    if (deleteBy == "id" || deleteBy == "ID" || deleteBy == "Id")
                        cmdStr = "DELETE FROM `seller` WHERE `ID` = " + index;
                    break;
                case E_RelationType.Platform:
                    cmdStr = "DELETE FROM `platform` WHERE `platform_name` = '" + index + "'";
                    if (deleteBy == "id" || deleteBy == "ID" || deleteBy == "Id")
                        cmdStr = "DELETE FROM `platform` WHERE `ID` = " + index;
                    break;
                case E_RelationType.Commodity:
                    cmdStr = "DELETE FROM `commodity` WHERE `commodity_name` = '" + index + "'";
                    if (deleteBy == "id" || deleteBy == "ID" || deleteBy == "Id")
                        cmdStr = "DELETE FROM `commodity` WHERE `ID` = " + index;
                    break;
                default:
                    return false;
            }
            cmd = new MySqlCommand(cmdStr, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 下架一件在售商品
        /// </summary>
        /// <param name="commodityID">商品id</param>
        /// <param name="sellerID">商家id</param>
        /// <param name="platformID">平台id</param>
        public bool RemoveFromShelves(SellingInfo sellingInfo)
        {
            string cmdStr = string.Format("DELETE FROM `selling` WHERE `commodity_id` = {0} AND `seller_id` = {1} AND `platform_id` = {2}",
                                          sellingInfo.commodity_id, sellingInfo.seller_id, sellingInfo.platform_id);

            cmd = new MySqlCommand(cmdStr, conn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 用户取消收藏商品的方法
        /// </summary>
        /// <param name="userID">用户id</param>
        /// <param name="notFavorite">要收藏的商品的信息</param>
        public void RemoveFromFavorites(string userID, SellingInfo notFavorite)
        {
            string cmdStr = string.Format("DELETE FROM `favorite` " +
                                          "WHERE `user_id` = {0} and `commodity_id` = {1} and `seller_id` = {2} and `platform_id` = {3}",
                                          userID, notFavorite.commodity_id, notFavorite.seller_id, notFavorite.platform_id);
            cmd = new MySqlCommand(cmdStr, conn);
            cmd.ExecuteNonQuery();
        }
        #endregion

        #region 进阶查询
        /// <summary>
        /// 获取不同商品的收藏量
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, int> GetFavoriteCount(string userName)
        {
            string insert = "";
            if (userName != "所有用户")
                insert = "JOIN `user` ON `user_id` = `ID` WHERE `user_name` = '" + userName + "' ";
            string cmdStr = string.Format("SELECT `commodity_name`, `sum` " +
                                          "FROM (SELECT `commodity_id`, COUNT(*) AS `sum` FROM `favorite` {0}GROUP BY `commodity_id`) AS temp " +
                                          "JOIN `commodity` ON `commodity_id` = `ID`", insert);
            Dictionary<string, int> result = new Dictionary<string, int>();

            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string key = reader[0].ToString();
                    int count = Convert.ToInt32(reader[1]);
                    result.Add(key, count);
                }
            }
            return result;
        }

        // 根据枚举类型获取对应的数据库表字段名
        private string GetColumnName(E_RelationType xType, string append)
        {
            switch (xType)
            {
                case E_RelationType.User:
                    return "user" + append; 
                case E_RelationType.Seller:
                    return "seller" + append;
                case E_RelationType.Platform:
                    return "platform" + append;
                default:
                    return null;
            }
        }

        private void CompleteNames(E_RelationType type, Dictionary<string, int> result)
        {
            List<string> names = Manager.instance.GetNames(type);
            foreach (string name in names)
            {
                if (!result.ContainsKey(name))
                {
                    result.Add(name, 0);
                }
            }
        }
        private void CompleteNames(E_RelationType type, Dictionary<string, float> result)
        {
            List<string> names = Manager.instance.GetNames(type);
            foreach (string name in names)
            {
                if (!result.ContainsKey(name))
                {
                    result.Add(name, 0);
                }
            }
        }

        /// <summary>
        /// 统计收藏商品的分布情况
        /// </summary>
        /// <param name="commodityName">指定一件商品或所有商品</param>
        /// <param name="xType">横坐标</param>
        /// <returns></returns>
        public Dictionary<string, int> GetFavoritesDistribution(string commodityName ,E_RelationType xType)
        {
            string tableName = GetColumnName(xType, "");
            string columnName = GetColumnName(xType, "_name");
            string columnID = GetColumnName(xType, "_id");
            Dictionary<string, int> result = new Dictionary<string, int>();

            if (columnName == null || columnID == null)
            {
                throw new ArgumentException("Invalid E_RelationType");
            }

            string insert = "";
            if (commodityName != "所有商品")
                insert = "JOIN `commodity` ON `commodity_id` = `ID` WHERE `commodity_name` = '" + commodityName + "' ";

            string cmdStr = string.Format("SELECT `{0}`, `sum` " +
                                          "FROM (SELECT `{1}`, COUNT(*) AS `sum` FROM `favorite` {2}GROUP BY `{3}`) AS temp " +
                                          "JOIN `{4}` ON `{5}` = `ID`", columnName, columnID, insert, columnID, tableName, columnID);
            
            cmd = new MySqlCommand(cmdStr, conn);

            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string key = reader[0].ToString();
                    int count = Convert.ToInt32(reader[1]);
                    result.Add(key, count);
                }
            }
            CompleteNames(xType, result);
            return result;
        }

        /// <summary>
        /// 获取商品在各个商家的历史价格的极差
        /// </summary>
        /// <param name="commodityName">商品名</param>
        /// <param name="timespan">时间跨度</param>
        /// <returns>商家名，价格差</returns>
        public Dictionary<string, float> GetHistoryPriceRange(string commodityName, int timespan)
        {
            Dictionary<string, float> result = new Dictionary<string, float>();
            string cmdStr = string.Format("SELECT (MAX(`price`) - MIN(`price`)) AS `diff`, `seller_name` " +
                                          "FROM `history_price` JOIN `commodity` ON `commodity_id` = `commodity`.`ID` " +
                                          "JOIN `seller` ON `seller_id` = `seller`.`ID` " +
                                          "WHERE `commodity_name` = '{0}' and DATE_SUB(CURDATE(), INTERVAL {1} DAY) <= `date` " +
                                          "GROUP BY `seller_id` " +
                                          "ORDER BY `diff` DESC", commodityName, timespan);
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    float diff = reader.GetFloat(0);
                    string seller_name = reader[1].ToString();
                    result.Add(seller_name, diff);
                }
            }
            CompleteNames(E_RelationType.Seller, result);
            return result;
        }

        /// <summary>
        /// 获取在售商品在不同商家间的价格
        /// </summary>
        /// <param name="commodityName">商品名</param>
        /// <param name="platformName">平台名</param>
        /// <returns></returns>
        public Dictionary<string, float> GetPriceDifferencesBetweenSellers(string commodityName, string platformName)
        {
            Dictionary<string, float> result = new Dictionary<string, float>();
            string cmdStr = string.Format("SELECT `price`, `seller_name` FROM `selling` " +
                                          "JOIN `seller` ON `seller_id` = `seller`.`ID` " +
                                          "JOIN `commodity` ON `commodity_id` = `commodity`.`ID` " +
                                          "JOIN `platform` ON `platform_id` = `platform`.`ID` " +
                                          "WHERE `commodity_name` = '{0}' AND `platform_name` = '{1}' " +
                                          "ORDER BY `price` DESC", commodityName, platformName);
            cmd = new MySqlCommand(cmdStr, conn);
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    float price = reader.GetFloat(0);
                    string seller_name = reader[1].ToString();
                    result.Add(seller_name, price);
                }
            }
            CompleteNames(E_RelationType.Seller, result);
            return result;
        }

        /// <summary>
        /// 获取用户收藏商品的价格倾向
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <returns></returns>
        public Dictionary<string, int> GetUserPriceInclination(string userName)
        {
            string insert = "";
            if (userName != "所有用户")
            {
                insert = "JOIN `user` ON `user_id` = `ID` WHERE `user_name` = '" + userName + "' ";
            }
            string cmdStr = string.Format("SELECT `price_floor` FROM `favorite` {0}ORDER BY `price_floor` ASC", insert);
            cmd = new MySqlCommand(cmdStr, conn);

            Dictionary<string, int> result = new Dictionary<string, int>();

            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    float priceFloor = reader.GetFloat(0);
                    if (priceFloor > 0 && priceFloor <= 10)
                    {
                        if (result.ContainsKey("0~10"))
                            result["0~10"]++;
                        else
                            result.Add("0~10", 1);
                    }
                    else if (priceFloor > 10 && priceFloor <= 50)
                    {
                        if (result.ContainsKey("10~50"))
                            result["10~50"]++;
                        else
                            result.Add("10~50", 1);
                    }
                    else if (priceFloor > 50 && priceFloor <= 100)
                    {
                        if (result.ContainsKey("50~100"))
                            result["50~100"]++;
                        else
                            result.Add("50~100", 1);
                    }
                    else if (priceFloor > 100 && priceFloor <= 200)
                    {
                        if (result.ContainsKey("100~200"))
                            result["100~200"]++;
                        else
                            result.Add("100~200", 1);
                    }
                    else if (priceFloor > 200 && priceFloor <= 500)
                    {
                        if (result.ContainsKey("200~500"))
                            result["200~500"]++;
                        else
                            result.Add("200~500", 1);
                    }
                    else if (priceFloor > 500 && priceFloor <= 1000)
                    {
                        if (result.ContainsKey("500~1000"))
                            result["500~1000"]++;
                        else
                            result.Add("500~1000", 1);
                    }
                    else if (priceFloor > 1000 && priceFloor <= 2000)
                    {
                        if (result.ContainsKey("1000~2000"))
                            result["1000~2000"]++;
                        else
                            result.Add("1000~2000", 1);
                    }
                    else if (priceFloor > 2000 && priceFloor <= 5000)
                    {
                        if (result.ContainsKey("2000~5000"))
                            result["2000~5000"]++;
                        else
                            result.Add("2000~5000", 1);
                    }
                    else if (priceFloor > 5000 && priceFloor <= 10000)
                    {
                        if (result.ContainsKey("5000~10000"))
                            result["5000~10000"]++;
                        else
                            result.Add("5000~10000", 1);
                    }
                    else if (priceFloor > 10000 && priceFloor <= 20000)
                    {
                        if (result.ContainsKey("10000~20000"))
                            result["10000~20000"]++;
                        else
                            result.Add("10000~20000", 1);
                    }
                    else if (priceFloor > 20000 && priceFloor <= 50000)
                    {
                        if (result.ContainsKey("20000~50000"))
                            result["20000~50000"]++;
                        else
                            result.Add("20000~50000", 1);
                    }
                    else if (priceFloor > 50000 && priceFloor <= 100000)
                    {
                        if (result.ContainsKey("50000~100000"))
                            result["50000~100000"]++;
                        else
                            result.Add("50000~100000", 1);
                    }
                }
            }
            return result;
        }
        #endregion

        /// <summary>
        /// 关闭数据库的连接
        /// </summary>
        public void Close()
        {
            conn.Close();
        }
    }
}
