﻿using DD_PJ;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pj_DBD
{
    public class UserMessage
    {
        public string ID;
        public string user_id;
        public string type;
        public string time;
        public string state;
        public string content;

        public static UserMessage ToMessage(MySqlDataReader reader)
        {
            UserMessage message = new UserMessage();
            message.ID      = reader.GetValue(0).ToString();
            message.user_id = reader.GetValue(1).ToString();
            message.type    = reader.GetValue(2).ToString();
            message.time    = reader.GetValue(3).ToString();
            message.state   = reader.GetValue(4).ToString();
            message.content = reader.GetValue(5).ToString();
            return message;
        }
        public override string ToString()
        {
            string str = "";
            str += type + "\r\t\r\t ";
            str += state + "\r\t\r\t ";
            str += time + "\r\t\r\t ";

            return str;
        }
    }
}
