use `PCS`;
insert into `commodity` (`commodity_name`, `category`) values 
('饼干', '食品类'),
('裙子', '服装类');