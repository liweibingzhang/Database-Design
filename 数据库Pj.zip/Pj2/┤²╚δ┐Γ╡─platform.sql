use `PCS`;
insert into `platform` (`platform_name`) values 
('PlatformA'),
('PlatformB'),
('PlatformC'),
('PlatformD'),
('PlatformE');