use `PCS`;

insert into `favorite` (`user_id`, `commodity_id`, `seller_id`, `platform_id`, `price_floor`) values 
(1, 5, 2, 1, 18.99),
(1, 4, 2, 1, 30.00),
(1, 6, 3, 2, 85.99),
(2, 7, 4, 2, 4.99),
(2, 8, 5, 3, 300.00)