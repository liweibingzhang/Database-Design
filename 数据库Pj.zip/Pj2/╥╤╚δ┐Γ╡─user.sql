use `PCS`;
insert into `user` (`user_name`, `password`, `fullname`, `phone_number`, `birth_date`, `home_address`) values
('u1', 'pass1', 'User One', '123-456-7890', '1990-01-01', '123 Main St'),
('u2', 'pass2', 'User Two', '234-567-8901', '1995-05-15', '456 Oak St'),
('u3', 'pass3', 'User Three', '345-678-9012', '1988-11-30', '789 Pine St'),
('u4', 'pass4', 'User Four', '456-789-0123', '1992-08-20', '101 Elm St'),
('u5', 'pass5', 'User Five', '567-890-1234', '1998-03-10', '202 Maple St');