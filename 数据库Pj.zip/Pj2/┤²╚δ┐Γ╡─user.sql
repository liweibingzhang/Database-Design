use `PCS`;
insert into `user` (`user_name`, `password`, `fullname`, `phone_number`, `birth_date`, `home_address`) values 
('userA', 'passA', 'John Doe', '123-456-7890', '1990-01-01', '123 Main St'),
('userB', 'passB', 'Jane Smith', '234-567-8901', '1995-05-15', '456 Oak St'),
('userC', 'passC', 'Bob Johnson', '345-678-9012', '1988-11-30', '789 Pine St'),
('userD', 'passD', 'Alice Brown', '456-789-0123', '1992-08-20', '101 Elm St'),
('userE', 'passE', 'Charlie Wilson', '567-890-1234', '1998-03-10', '202 Maple St');